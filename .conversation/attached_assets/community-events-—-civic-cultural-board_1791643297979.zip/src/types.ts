export type EventCategory = 'Music' | 'Workshop' | 'Food' | 'Sports' | 'Kids';

export interface EventItem {
  id: string;
  title: string;
  category: EventCategory;
  city: string;
  venue: string;
  neighborhood: string;
  dateTime: string;
  price: number;
  isFree?: boolean;
  imageUrl: string;
  imageAlt: string;
  description: string;
  status: 'active' | 'inactive';
  attendeesCount: number;
  spotsLeft?: number;
  badgeNote?: string;
  matchedVia?: string;
}

export interface CategoryPreference {
  id: string;
  name: string;
  upcomingCount: number;
  description: string;
  icon: string;
  selected: boolean;
}

export interface StickerItem {
  id: string;
  label: string;
  classes: string;
  rotate: string;
}

export interface CardDesignState {
  theme: 'warm-atelier' | 'indigo-midnight' | 'civic-emerald';
  stickers: StickerItem[];
  attendeeName: string;
  eventId: string;
}

export type AppScreen =
  | 'discover-events'
  | 'my-feed'
  | 'favourite-categories'
  | 'card-designer'
  | 'admin-portal'
  | 'sign-in';

export interface ToastMessage {
  id: string;
  title: string;
  desc: string;
  type?: 'success' | 'info' | 'error';
}
