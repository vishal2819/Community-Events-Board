import { EventItem, CategoryPreference, StickerItem } from '../types';

export const INITIAL_EVENTS: EventItem[] = [
  {
    id: 'evt-1',
    title: 'Bangalore Acoustic Evening & Vinyl Showcase',
    category: 'Music',
    city: 'Bengaluru',
    venue: 'The Teal House, 12th Main',
    neighborhood: 'Indiranagar, Bengaluru',
    dateTime: 'Sat, Mar 29 • 6:30 PM IST',
    price: 799,
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCvcVUPidmDGadPKLPQqOis_1MSA4KQ35npFzyyjdUj2h2TLQaDGNQBiFWhLi08kFCUoSmbJ-kyLIvi9hV23E5kJPZfr4RQiAHPjJvH4sc_z0v8FK5FidltdzwGUG_kxIInUy3GqA9BbURvb0tC1WMtjkw_WcOYxjbzeWJ1r5e0SiBDR6yyicjirGSVVjxarF1QTVncp6kDe7QXvb8KF33aEXuE3FDbBCqlCD3zJbU_ZkvAFE0ZXMwQ',
    imageAlt: 'An intimate evening acoustic music concert setting in Bengaluru with warm stage tungsten lights, vintage vinyl records displayed along a polished wooden rail, a singer guitarist performing on an amber-lit stool surrounded by focused audience patrons.',
    description: 'Experience soulful acoustic melodies alongside an exclusive showcase of curated vintage vinyl records in Indiranagar. Local artists and light refreshments included.',
    status: 'active',
    attendeesCount: 142,
    matchedVia: 'Music'
  },
  {
    id: 'evt-2',
    title: 'Artisanal Sourdough & Fermentation Lab',
    category: 'Workshop',
    city: 'Bengaluru',
    venue: 'Crust & Crumb Studio, 4th Block',
    neighborhood: 'Koramangala, Bengaluru',
    dateTime: 'Sun, Mar 30 • 10:00 AM IST',
    price: 1450,
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDhFXBmhufTlPEAb3skOtGF4yE47swnZLdBxsbvXKP-BdVuDmH80bU75AllZes8BDxVpA3_2NKacqDdQIKj78gW2ZrpWh75qOb8qfRrDCTvISFefzbXTD9pbJg31POXuqO1XORQthFBMmbSRFWGW0mQX8ascEJdoWfBWbfvUaXgHuO3ODAok-qn-_zBE5wba8r9MZD0oZIZggrNGhZVzuCK2vwThIU-7luCv3TLbjLdIWfch31n3iAR',
    imageAlt: 'Sunlit artisanal kitchen workshop table with dusted flour, rustic sourdough loaves with crisp golden crusts, glass fermentation jars with natural starter bubbling, hands gently kneading artisanal dough.',
    description: 'Master sourdough fermentation and baking kinetics in a professional micro-bakery setting. Starter culture, proofing basket, and fresh loaves to take home.',
    status: 'active',
    attendeesCount: 16,
    spotsLeft: 8,
    matchedVia: 'Workshop'
  },
  {
    id: 'evt-3',
    title: 'Old Town Heritage Food Walk & Tasting',
    category: 'Food',
    city: 'Bengaluru',
    venue: '8th Cross Heritage Junction',
    neighborhood: 'Malleshwaram, Bengaluru',
    dateTime: 'Sat, Apr 5 • 8:00 AM IST',
    price: 650,
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD2o3UjjRooqMMSVmnV5hJ3_pfWhuc1icAfhRNNg8r71csYhP5xWP4zXEnDbIq8CYeVryHO2Sca9bvg1l9ggBtSs-kn1aX3vERNL9kK2CwFKKpdJI5K3ON8Fg3VEz4MMYkwS9mBI4Q6qD8Z5z0pfgIg-i9lSLLcIqAkmT7t5DBQJAwHqJJBanwdITzzrqwv0iYY90T6GgLK4fUzAXeDh8m_vXS8JKMlBrmm-jEJrCX2hk8YxWQ3xJzl',
    imageAlt: 'Traditional South Indian breakfast culinary walk in Malleshwaram featuring steaming hot filter coffee in brass dabara sets, crisp golden masala dosa served on banana leaves, and smiling street market walkers.',
    description: 'Walk through historic lanes in Malleshwaram savoring legendary culinary institutions dating back six decades with local cultural historians.',
    status: 'active',
    attendeesCount: 28,
    badgeNote: 'Guided by local historians',
    matchedVia: 'Food & Drink'
  },
  {
    id: 'evt-4',
    title: 'Weekend Sunset 5K Community Run & Social',
    category: 'Sports',
    city: 'Bengaluru',
    venue: 'Bandstand, Cubbon Park',
    neighborhood: 'Cubbon Park, Bengaluru',
    dateTime: 'Sun, Apr 6 • 5:00 PM IST',
    price: 0,
    isFree: true,
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAxV4H4FCJeviBDTHA8O7RISrIDfJNIx1DXJQtJnrNJPldFQnRheqSxgjAqEq-A-RmEpitLkKkaeOkPxYiU0Dg6emQHorCAwbAIxFvSGlgNl_w4c5SFgPuLlw1JZIYWtPaR-TB2Ob7dMISeYC4Wu7qwmWpLn20zQ4o8951lhdKX_iHlfOar-0jZz8GkCc8BxSb76TFwNiNGDtSgwaGtM3oUh3F7wWhVrMYO4WunHk_vK8BBTYPlNowd',
    imageAlt: 'Lush green bamboo groves and bamboo paths of Cubbon park during golden hour sunset, a vibrant diverse group of community joggers and runners in casual athletic wear stretching and laughing together on the red clay trails.',
    description: 'Join neighborhood fitness enthusiasts for an easy sunset run through scenic green loops, followed by fresh coconut water and warm banter.',
    status: 'active',
    attendeesCount: 95,
    badgeNote: 'All paces welcome',
    matchedVia: 'Sports'
  },
  {
    id: 'evt-5',
    title: 'Little Explorers Robotics & Clay Lab',
    category: 'Kids',
    city: 'Bengaluru',
    venue: 'Maker Hive Studio, Outer Ring Rd',
    neighborhood: 'Whitefield, Bengaluru',
    dateTime: 'Sat, Apr 12 • 11:00 AM IST',
    price: 899,
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBZwsxI2BVEn5-a3T_DEw34S7ktO1iuDpT0x39bLd8eKY-gjLiYDlSJNCppDF8FFhNY1SCyb9OUUzRNzVfXF38QO8O1Fft0Z1RuUO0w_6R3-uHZmujPmkG7pTs3ljDwQcOuMZD1Kbw9i8MVTh5aPkcmrX_K9bxaONOM6j9h8TQSMWaqGJzWl8Ftk251ILrVs-y0lrnSsPNfaV1jtf1UZljVtb5RqLhPqCyFTHKhSoFn2EIgf87C2EX0',
    imageAlt: 'Children engaged in a cheerful maker laboratory workshop with colorful motorized Lego robotics pieces, clay animal sculptures, and educational interactive gadgets under bright studio lighting.',
    description: 'A hands-on interactive creative workshop for young curious minds combining beginner mechanical motor sensors and tactile air-dry clay modeling.',
    status: 'active',
    attendeesCount: 34,
    badgeNote: 'Ages 6–12 • Materials included',
    matchedVia: 'Kids & Family'
  },
  {
    id: 'evt-6',
    title: 'Indie Jazz Quartet Live at the Amphitheater',
    category: 'Music',
    city: 'Bengaluru',
    venue: 'Rangoli Metro Art Center',
    neighborhood: 'MG Road, Bengaluru',
    dateTime: 'Sun, Apr 13 • 7:00 PM IST',
    price: 1200,
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBLeOyvs9E7cJcYYmkUZKG3xidjFQDCrtBbmhg7HDvLzHRMO9LWkqoxIjcWLSJ9ubT32wTb4YGMHiutSys365Rn7-QzFh7usaxqvjBD9KpgI4kvCGDtTM5KUYkBZpjHrQdbuAGxz5l6ML8VKiIk974WHboxuDXxeDdSdUW-npEMRA17nn-N7G7G5KS8U0SZtXTzxymMJg4duk2TASUuOkoDpwrC984gC5iYtMqSBVikdRo8Elt6KM7Q',
    imageAlt: 'Outdoor twilight concert at an open-air stone amphitheater with brass saxophones, double bass player in silhouette against soft purple and deep blue evening stage lighting with city lights in the distant background.',
    description: 'An open-air evening filled with modern jazz improvisations, brass horns, syncopated rhythms, and artisanal coffee under the starlit sky.',
    status: 'active',
    attendeesCount: 110,
    badgeNote: 'Seated amphitheater',
    matchedVia: 'Music'
  },
  {
    id: 'evt-7',
    title: 'Indie Vinyl Sessions & Sunset Live',
    category: 'Music',
    city: 'Bengaluru',
    venue: 'The Record Loft, 100ft Road',
    neighborhood: 'Indiranagar, Bengaluru',
    dateTime: 'Sat, Oct 18 • 6:30 PM IST',
    price: 799,
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC1VS6WVjrraK2HF7jdyDKDqKOHJtBEeaGZMshiGJQdPNT3A9Xw-ZRpkmsBOm3tZh3dLdYiL1PXly5rqkFjk9csu2fjnuawhmC0ue16Vpmy0D1v7MQi9fFnlvwfuKm4MrJ8DtbrAuFBPP2SzdjvOE4wytFiIHj4w4CYDPTva4qMGhlldjw_lzfMjpCtqAvb_NQQvBK9wycWoxiXQv8vi0fpBlmRwk_7VeLlhOKICxyYR8yOtLk_KPxL',
    imageAlt: 'A warm atmospheric listening lounge in Indiranagar Bengaluru at golden hour with vintage turntables vinyl records audiophile speakers and warm ambient amber and indigo spotlighting',
    description: 'Intimate acoustic performance followed by rare 1970s South Asian psych rock vinyl listening session on high-fidelity analog setup.',
    status: 'active',
    attendeesCount: 142,
    matchedVia: 'Music'
  },
  {
    id: 'evt-8',
    title: 'Ceramic Wheelthrowing & Glaze Masterclass',
    category: 'Workshop',
    city: 'Bengaluru',
    venue: 'Clay Ground Atelier, 5th Block',
    neighborhood: 'Koramangala, Bengaluru',
    dateTime: 'Sun, Oct 19 • 11:00 AM IST',
    price: 1850,
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBu7FKIn-h-RZ03kYhFsWw7jTZ8svDSzJ3CuDibCBUcNk2wYxKwa1fVb2Ko1dWP3MJpydGVHw8bpUQeG5HOBcMYF9vxeGPKsfMA6lbpA2b0AiDcwtUsq09kWzJL1Qf9Vol6GdRNcJsmLoJfEGdXbxxRy2F63rfG3Ft2jTftf8kx-unLoZxIo075yKLUs4zUjHZl8Ip1f5Lxo9JlOX4Xz-pS3erjjf1fUBHEtadB4lS7Obcg_w7PFDd4',
    imageAlt: 'Hands shaping warm earthy terracotta clay on an artisanal potter wheel in an airy Koramangala studio flooded with morning sunlight ceramic mugs and raw glaze pots',
    description: 'Hands-on studio masterclass covering centering, pulling, trimming, and natural wood-ash glaze formulations. All equipment provided.',
    status: 'active',
    attendeesCount: 12,
    spotsLeft: 4,
    matchedVia: 'Workshop'
  },
  {
    id: 'evt-9',
    title: 'Cubbon Morning Runners 10K & Social Breakfast',
    category: 'Sports',
    city: 'Bengaluru',
    venue: 'Queen Victoria Statue Gate',
    neighborhood: 'Cubbon Park, Bengaluru',
    dateTime: 'Sun, Oct 19 • 6:00 AM IST',
    price: 0,
    isFree: true,
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAZiGorqenIzx0QPq1sjIggHoFBIPivxo4mksV3i0gyT6fe6tl9yOqBfmTwPMBTT1N74665MkBdcMn0PfxVSHLKrvjIyjX8lGTbBF16szBAm39BJShNlrrV3cc04lep4nzsHMCoi17D6D4sR4VlFWW4cufnllHo1jEEQINEf2w9Lx4_hs4TnoGT72laBqI1R0n392w1K3q3cigDpkgoF1XvRoLYxFMPHNTtp8zQonE9NH1lbNNG0KG8',
    imageAlt: 'Vibrant group of community runners stretching and jogging beneath ancient bamboo and rain trees in lush Cubbon Park Bangalore early morning mist sunbeams',
    description: 'Scenic paced community run across heritage Cubbon trails followed by South Indian filter coffee and dosas at iconic Central Tiffin Room.',
    status: 'active',
    attendeesCount: 88,
    badgeNote: 'All paces welcome',
    matchedVia: 'Sports'
  },
  {
    id: 'evt-10',
    title: 'Night Cycling Explorers: Heritage Circuit',
    category: 'Sports',
    city: 'Bengaluru',
    venue: 'Sankey Tank East Gate',
    neighborhood: 'Malleshwaram, Bengaluru',
    dateTime: 'Fri, Oct 24 • 9:30 PM IST',
    price: 450,
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCqCd-nM_9vKKMqgMLpOtj2R8kasr_HQkTtngXtKS3baFsc0OU9LfluJdvdExQ89GC3YaMWhZZ5g6IxqZRxmx6yq7o07OBtSImsa6Dlvl_o1r6jCPTgnTUWBOAyVslG3_WIU6s3Q5XyTmExroTSp1J6OZnJJpboaAsKUQ0SBlI2cQbfNoEe-vt0_n0fQKhQ6axesAiL9D_lFGTsQDLPan3hNIlda8jKdCJV2FzCGlAwJZHGbCGBq3rH',
    imageAlt: 'Cyclists with glowing safety LED bike lights gathered at an illuminated colonial heritage street in Malleshwaram Bangalore at night under old stone archways',
    description: 'Guided 18km nocturnal bicycle cruise winding through heritage conservancy lanes, ancient temple streets, and late-night sweet markets.',
    status: 'active',
    attendeesCount: 52,
    badgeNote: 'Includes safety marshal & chai',
    matchedVia: 'Sports'
  },
  {
    id: 'evt-11',
    title: 'Monsoon Rooftop Pottery',
    category: 'Workshop',
    city: 'Bengaluru',
    venue: 'The Open Terrace Co., Indiranagar',
    neighborhood: 'Indiranagar, Bengaluru',
    dateTime: 'Apr 10, 2025 • 04:00 PM - 07:00 PM',
    price: 1200,
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAe8CWaf1F1-P6kFnVq_2dOUhfi91nt8Qy2YQdCaJD98LyjIrQ1ypjGGQIwAqDyF7cFxo4YLOH_us05IVuvMbJE3yegfbod465FFrLTogNpNQU16FEWBpai8LmzTCcutrY8zAY82pkGZWFn5wgD1Eb8hy341Tl8CB0b0drU9vi1-NntJpw3NFKWgsSOrKn3kQzC0WsUdVVgP8eeQ-cKp4mDnxwYDXlvgrlONG8BPHbMsy3sRl_NEjcd',
    imageAlt: 'Clay wheel pottery workshop on a green lush open terrace overlooking Bangalore trees during cloudy afternoon ambient natural warm tone',
    description: 'Hands-on clay centering, trimming, and terracotta glazing in an airy open-sky setting.',
    status: 'inactive',
    attendeesCount: 0,
    badgeNote: 'Draft • Unpublished',
    matchedVia: 'Workshop'
  },
  {
    id: 'evt-12',
    title: 'Koramangala Community Chess & Board Meet',
    category: 'Sports',
    city: 'Bengaluru',
    venue: 'Dyu Art Cafe',
    neighborhood: 'Koramangala, Bengaluru',
    dateTime: 'Sat, May 3 • 4:00 PM IST',
    price: 250,
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAxV4H4FCJeviBDTHA8O7RISrIDfJNIx1DXJQtJnrNJPldFQnRheqSxgjAqEq-A-RmEpitLkKkaeOkPxYiU0Dg6emQHorCAwbAIxFvSGlgNl_w4c5SFgPuLlw1JZIYWtPaR-TB2Ob7dMISeYC4Wu7qwmWpLn20zQ4o8951lhdKX_iHlfOar-0jZz8GkCc8BxSb76TFwNiNGDtSgwaGtM3oUh3F7wWhVrMYO4WunHk_vK8BBTYPlNowd',
    imageAlt: 'Wooden chess board and handcrafted pieces on a rustic cafe table with filter coffee and players in deep friendly focus',
    description: 'Casual blitz, rapid rounds, and classic tabletop strategy for players of all levels in a verdant courtyard setting.',
    status: 'active',
    attendeesCount: 42,
    badgeNote: 'All equipment provided',
    matchedVia: 'Sports'
  }
];

export const INITIAL_CATEGORIES: CategoryPreference[] = [
  {
    id: 'music',
    name: 'Music',
    upcomingCount: 24,
    description: 'Live gigs, indie showcases, acoustic evenings & festivals',
    icon: 'music_note',
    selected: true
  },
  {
    id: 'workshop',
    name: 'Workshop',
    upcomingCount: 16,
    description: 'Craft pottery, sourdough baking, design & creative masterclasses',
    icon: 'palette',
    selected: true
  },
  {
    id: 'food',
    name: 'Food & Drink',
    upcomingCount: 19,
    description: 'Heritage food walks, pop-up dinners, farmer markets & tastings',
    icon: 'restaurant',
    selected: false
  },
  {
    id: 'sports',
    name: 'Sports',
    upcomingCount: 12,
    description: 'Community runs, weekend badminton, cycling tours & yoga in parks',
    icon: 'directions_run',
    selected: true
  },
  {
    id: 'kids',
    name: 'Kids & Family',
    upcomingCount: 15,
    description: 'STEM labs, puppet shows, storytelling & family weekend carnivals',
    icon: 'auto_awesome',
    selected: false
  }
];

export const STICKER_CATALOG: Record<string, StickerItem> = {
  vinyl: {
    id: 'vinyl',
    label: '🎵 Vinyl Groove',
    classes: 'bg-[#EEF2FF] text-[#4338CA] border border-[#C7D2FE]',
    rotate: '-rotate-2'
  },
  coldbrew: {
    id: 'coldbrew',
    label: '☕ Cold Brew',
    classes: 'bg-[#FFFBEB] text-[#B45309] border border-[#FDE68A]',
    rotate: 'rotate-3'
  },
  community: {
    id: 'community',
    label: '⭐ Community Pick',
    classes: 'bg-[#FDF2F8] text-[#BE185D] border border-[#FBCFE8]',
    rotate: '-rotate-1'
  },
  eco: {
    id: 'eco',
    label: '🌿 Eco Certified',
    classes: 'bg-[#F0FDF4] text-[#15803D] border border-[#BBF7D0]',
    rotate: 'rotate-2'
  },
  vip: {
    id: 'vip',
    label: '🎟️ VIP Access',
    classes: 'bg-[#F0F9FF] text-[#0369A1] border border-[#BAE6FD]',
    rotate: '-rotate-3'
  }
};
