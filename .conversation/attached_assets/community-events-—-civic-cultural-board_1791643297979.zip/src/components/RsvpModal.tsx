import React, { useState } from 'react';
import { EventItem } from '../types';

interface RsvpModalProps {
  event: EventItem | null;
  onClose: () => void;
  onConfirm: (attendeeName: string, tickets: number) => void;
  onCustomizePass: (eventId: string, attendeeName: string) => void;
}

export const RsvpModal: React.FC<RsvpModalProps> = ({
  event,
  onClose,
  onConfirm,
  onCustomizePass
}) => {
  const [attendeeName, setAttendeeName] = useState('Arun K. Ramaswamy');
  const [ticketCount, setTicketCount] = useState(1);
  const [confirmed, setConfirmed] = useState(false);

  if (!event) return null;

  const totalPrice = event.isFree ? 0 : event.price * ticketCount;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setConfirmed(true);
    onConfirm(attendeeName, ticketCount);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1f1b17]/50 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl overflow-hidden border border-[#eae1da]">
        {/* Header Image Header */}
        <div className="relative h-36 w-full bg-[#f6ece6]">
          <img
            src={event.imageUrl}
            alt={event.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#1f1b17]/80 to-transparent" />
          <button
            type="button"
            onClick={onClose}
            className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/40 hover:bg-black/60 text-white flex items-center justify-center transition-colors"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
          <div className="absolute bottom-3 left-4 right-4 text-white">
            <span className="text-xs uppercase tracking-wider font-semibold bg-[#3525cd] px-2 py-0.5 rounded-full text-white">
              {event.category}
            </span>
            <h3 className="text-lg font-bold truncate mt-1">{event.title}</h3>
          </div>
        </div>

        {confirmed ? (
          <div className="p-6 text-center space-y-4">
            <div className="w-14 h-14 rounded-full bg-[#85f8c4]/30 text-[#005338] mx-auto flex items-center justify-center">
              <span
                className="material-symbols-outlined text-[32px]"
                style={{ fontVariationSettings: "'FILL' 1" }}
              >
                check_circle
              </span>
            </div>
            <div>
              <h4 className="text-xl font-bold text-[#1f1b17]">
                RSVP Confirmed!
              </h4>
              <p className="text-sm text-[#464555] mt-1">
                You're registered for {event.title}. A gate pass for{' '}
                <strong className="text-[#1f1b17]">{attendeeName}</strong> has been
                provisioned.
              </p>
            </div>

            <div className="bg-[#fcf2eb] p-3.5 rounded-xl text-left text-xs space-y-1.5 border border-[#eae1da]">
              <div className="flex justify-between">
                <span className="text-[#464555]">Date & Time:</span>
                <span className="font-semibold text-[#1f1b17]">{event.dateTime}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#464555]">Venue:</span>
                <span className="font-semibold text-[#1f1b17]">{event.neighborhood}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#464555]">Pass ID:</span>
                <span className="font-mono font-semibold text-[#3525cd]">
                  #BLR-2025-{Math.floor(1000 + Math.random() * 9000)}
                </span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onCustomizePass(event.id, attendeeName);
                }}
                className="flex-1 py-2.5 px-4 rounded-xl bg-[#3525cd] hover:bg-[#4f46e5] text-white text-sm font-semibold transition-all shadow-md flex items-center justify-center gap-2"
              >
                <span className="material-symbols-outlined text-[18px]">
                  palette
                </span>
                <span>Personalize Card Pass</span>
              </button>
              <button
                type="button"
                onClick={onClose}
                className="py-2.5 px-4 rounded-xl bg-[#f6ece6] hover:bg-[#f0e6e0] text-[#1f1b17] text-sm font-semibold transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#eae1da]">
              <div className="flex items-center gap-1.5 text-xs text-[#3525cd] font-semibold">
                <span className="material-symbols-outlined text-[16px]">
                  calendar_month
                </span>
                <span>{event.dateTime}</span>
              </div>
              <span className="text-xs text-[#625d5b]">{event.neighborhood}</span>
            </div>

            <div className="space-y-1.5">
              <label
                htmlFor="rsvp-name"
                className="block text-xs font-semibold text-[#1f1b17]"
              >
                Primary Attendee Full Name <span className="text-red-500">*</span>
              </label>
              <input
                id="rsvp-name"
                type="text"
                required
                value={attendeeName}
                onChange={(e) => setAttendeeName(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg bg-[#fcf2eb] border border-[#eae1da] text-[#1f1b17] focus:outline-none focus:ring-2 focus:ring-[#3525cd]/20"
                placeholder="e.g. Arun K. Ramaswamy"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-[#1f1b17]">
                  Pass Quantity
                </label>
                <div className="flex items-center rounded-lg border border-[#eae1da] bg-[#fcf2eb] overflow-hidden">
                  <button
                    type="button"
                    disabled={ticketCount <= 1}
                    onClick={() => setTicketCount(ticketCount - 1)}
                    className="px-3 py-2 text-sm text-[#1f1b17] hover:bg-[#f6ece6] disabled:opacity-40"
                  >
                    -
                  </button>
                  <span className="flex-1 text-center text-sm font-semibold text-[#1f1b17]">
                    {ticketCount}
                  </span>
                  <button
                    type="button"
                    disabled={ticketCount >= 6}
                    onClick={() => setTicketCount(ticketCount + 1)}
                    className="px-3 py-2 text-sm text-[#1f1b17] hover:bg-[#f6ece6] disabled:opacity-40"
                  >
                    +
                  </button>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-[#1f1b17]">
                  Total Amount
                </label>
                <div className="px-3 py-2 text-sm font-bold text-[#1f1b17] bg-[#fcf2eb] border border-[#eae1da] rounded-lg flex items-center justify-between">
                  <span>{event.isFree ? 'Free' : `₹${totalPrice.toLocaleString()}`}</span>
                  {event.isFree && (
                    <span className="text-[10px] uppercase font-bold text-[#005338] bg-[#85f8c4]/40 px-1.5 py-0.5 rounded">
                      Community
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-lg text-sm text-[#625d5b] hover:text-[#1f1b17] transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-[#3525cd] hover:bg-[#4f46e5] text-white text-sm font-semibold shadow-md transition-all active:scale-95"
              >
                Confirm RSVP
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
