import React, { useState, useMemo } from 'react';
import { EventItem, EventCategory, AppScreen } from '../types';

interface AdminPortalProps {
  events: EventItem[];
  onToggleStatus: (id: string) => void;
  onSaveEvent: (eventData: Partial<EventItem> & { id?: string }) => void;
  onArchiveEvent: (id: string) => void;
  onNavigate: (screen: AppScreen) => void;
  onShowToast: (title: string, desc: string) => void;
  onDesignPass: (eventId: string) => void;
}

export const AdminPortal: React.FC<AdminPortalProps> = ({
  events,
  onToggleStatus,
  onSaveEvent,
  onArchiveEvent,
  onNavigate,
  onShowToast,
  onDesignPass
}) => {
  const [filterTab, setFilterTab] = useState<'all' | 'active' | 'inactive'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [editingEventId, setEditingEventId] = useState<string | null>(null);

  // Form State
  const [formTitle, setFormTitle] = useState('');
  const [formCategory, setFormCategory] = useState<EventCategory>('Music');
  const [formCity, setFormCity] = useState('Bengaluru');
  const [formVenue, setFormVenue] = useState('');
  const [formDateTime, setFormDateTime] = useState('');
  const [formPrice, setFormPrice] = useState<number>(799);
  const [formIsFree, setFormIsFree] = useState(false);
  const [formImageUrl, setFormImageUrl] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formIsActive, setFormIsActive] = useState(true);

  // Open Drawer for Create
  const handleOpenCreateDrawer = () => {
    setEditingEventId(null);
    setFormTitle('');
    setFormCategory('Music');
    setFormCity('Bengaluru');
    setFormVenue('The Teal House, 12th Main Road, Indiranagar');
    setFormDateTime('2025-04-18T18:30');
    setFormPrice(799);
    setFormIsFree(false);
    setFormImageUrl(
      'https://lh3.googleusercontent.com/aida-public/AB6AXuBcWgWuIRMRtSVZ6dtefF_DicREFKlFwWhzCsDKQrUM4rZgwdTeSr5h1xnQhapTYjFPAHNIVCAslLuZ1GPEbys6Ze_b33lR_xJmk5mAzPa2YznPqqxFyVWASOj1aPHRDfddIjVTIpVB72f7bu8OAjW3ItR2gEmxRejlG52hWK5EbYoLAOSStb_u-G2cIho6lQagfbsxfsrbTb-ija-JuGOCqIH5JNKMu_Wr6qGqLkQwJCmh3K8GyRwe'
    );
    setFormDescription(
      'Experience soulful acoustic melodies alongside an exclusive showcase of curated vintage vinyl records in Indiranagar. Local artists and light refreshments included.'
    );
    setFormIsActive(true);
    setIsDrawerOpen(true);
  };

  // Open Drawer for Edit
  const handleOpenEditDrawer = (ev: EventItem) => {
    setEditingEventId(ev.id);
    setFormTitle(ev.title);
    setFormCategory(ev.category);
    setFormCity(ev.city);
    setFormVenue(ev.venue || ev.neighborhood);
    setFormDateTime(ev.dateTime);
    setFormPrice(ev.price);
    setFormIsFree(Boolean(ev.isFree));
    setFormImageUrl(ev.imageUrl);
    setFormDescription(ev.description);
    setFormIsActive(ev.status === 'active');
    setIsDrawerOpen(true);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveEvent({
      id: editingEventId || undefined,
      title: formTitle,
      category: formCategory,
      city: formCity,
      venue: formVenue,
      neighborhood: `${formVenue}, ${formCity}`,
      dateTime: formDateTime.includes('T') ? formDateTime.replace('T', ' ') : formDateTime,
      price: formIsFree ? 0 : formPrice,
      isFree: formIsFree,
      imageUrl: formImageUrl,
      description: formDescription,
      status: formIsActive ? 'active' : 'inactive'
    });
    setIsDrawerOpen(false);
    onShowToast(
      editingEventId ? 'Event Updated' : 'Event Created',
      `"${formTitle}" is now recorded in Bengaluru municipal stream.`
    );
  };

  const filteredEvents = useMemo(() => {
    return events.filter((ev) => {
      if (filterTab === 'active' && ev.status !== 'active') return false;
      if (filterTab === 'inactive' && ev.status !== 'inactive') return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = ev.title.toLowerCase().includes(q);
        const matchesVenue = ev.venue.toLowerCase().includes(q) || ev.neighborhood.toLowerCase().includes(q);
        if (!matchesTitle && !matchesVenue) return false;
      }
      return true;
    });
  }, [events, filterTab, searchQuery]);

  const activeCount = events.filter((e) => e.status === 'active').length;
  const inactiveCount = events.filter((e) => e.status === 'inactive').length;

  return (
    <div className="w-full max-w-7xl mx-auto px-4 md:px-8 py-8 md:py-12">
      {/* Top KPI Bar & Administrative Header */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-8">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded-full bg-[#3525cd]/10 text-[#3525cd] text-xs font-bold uppercase tracking-wider">
              Curator Access
            </span>
            <span className="text-xs text-[#464555] flex items-center gap-1 font-medium">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              Node #01 • Live Operations
            </span>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-[#1f1b17] tracking-tight">
            Event Operations
          </h1>
          <p className="text-sm text-[#464555] max-w-2xl">
            Create, moderate, edit, and toggle visibility for community events in Bengaluru. Real-time synchronisation active across discovery feeds.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-4">
          {/* Metric Badges */}
          <div className="flex items-center gap-3 bg-[#fcf2eb] px-4 py-2 rounded-xl shadow-sm border border-[#eae1da]/70">
            <div className="flex items-center gap-1.5 text-xs text-[#1f1b17]">
              <span className="material-symbols-outlined text-[18px] text-[#3525cd]">
                groups
              </span>
              <span className="font-bold">1,240</span>
              <span className="text-[#464555]">RSVPs</span>
            </div>
            <span className="text-[#c7c4d8] text-xs">•</span>
            <div className="flex items-center gap-1.5 text-xs text-[#1f1b17]">
              <span className="material-symbols-outlined text-[18px] text-[#005338]">
                pie_chart
              </span>
              <span className="font-bold text-[#005338]">98.2%</span>
              <span className="text-[#464555]">Cap.</span>
            </div>
          </div>

          <button
            type="button"
            onClick={handleOpenCreateDrawer}
            className="inline-flex items-center justify-center gap-1.5 px-5 py-2.5 rounded-lg bg-[#3525cd] hover:bg-[#4f46e5] text-white text-sm font-semibold shadow-md transition-all active:scale-[0.98] cursor-pointer"
          >
            <span className="material-symbols-outlined text-[20px]">add</span>
            <span>Add New Event</span>
          </button>
        </div>
      </div>

      {/* Administrative Table & Filter Shell */}
      <div className="w-full bg-white rounded-xl shadow-md overflow-hidden border border-[#eae1da]">
        {/* Status Tabs & Global Search */}
        <div className="p-4 md:p-5 bg-[#fcf2eb]/60 border-b border-[#eae1da] flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-1 bg-[#f6ece6] p-1 rounded-lg">
            <button
              type="button"
              onClick={() => setFilterTab('all')}
              className={`px-3.5 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                filterTab === 'all'
                  ? 'bg-white text-[#1f1b17] shadow-sm'
                  : 'text-[#464555] hover:text-[#1f1b17]'
              }`}
            >
              All Events <span className="ml-1 text-[#464555] font-normal">{events.length}</span>
            </button>
            <button
              type="button"
              onClick={() => setFilterTab('active')}
              className={`px-3.5 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                filterTab === 'active'
                  ? 'bg-white text-[#1f1b17] shadow-sm'
                  : 'text-[#464555] hover:text-[#1f1b17]'
              }`}
            >
              Active <span className="ml-1 text-[#464555] font-normal">{activeCount}</span>
            </button>
            <button
              type="button"
              onClick={() => setFilterTab('inactive')}
              className={`px-3.5 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                filterTab === 'inactive'
                  ? 'bg-white text-[#1f1b17] shadow-sm'
                  : 'text-[#464555] hover:text-[#1f1b17]'
              }`}
            >
              Inactive / Drafts <span className="ml-1 text-[#464555] font-normal">{inactiveCount}</span>
            </button>
          </div>

          <div className="flex items-center gap-3">
            <div className="relative w-full md:w-64">
              <span className="material-symbols-outlined absolute left-2.5 top-2.5 text-[18px] text-[#777587]">
                search
              </span>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Filter by title, area..."
                className="w-full pl-9 pr-3 py-1.5 rounded-lg bg-white text-[#1f1b17] text-xs placeholder:text-[#777587] focus:outline-none focus:ring-2 focus:ring-[#3525cd]/20 transition-all shadow-xs border border-[#eae1da]"
              />
            </div>
            <button
              type="button"
              onClick={() => onShowToast('Export queued', 'CSV export will be sent to curator@civic.blr.')}
              title="Export CSV"
              className="p-2 rounded-lg bg-[#f6ece6] hover:bg-[#f0e6e0] text-[#464555] transition-colors cursor-pointer border border-[#eae1da]"
            >
              <span className="material-symbols-outlined text-[18px]">download</span>
            </button>
          </div>
        </div>

        {/* Event Listing Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#f6ece6] text-[#464555] text-xs font-bold uppercase tracking-wider border-b border-[#eae1da]">
                <th className="py-3.5 px-6">Event & Category</th>
                <th className="py-3.5 px-4">City & Venue</th>
                <th className="py-3.5 px-4">Date & Schedule</th>
                <th className="py-3.5 px-4">Price</th>
                <th className="py-3.5 px-4">Public Status</th>
                <th className="py-3.5 px-6 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="text-xs text-[#1f1b17] divide-y divide-[#eae1da]/60">
              {filteredEvents.map((ev) => {
                const isActive = ev.status === 'active';

                let categoryBadge = 'bg-[#EEF2FF] text-[#4338CA]';
                if (ev.category === 'Workshop') categoryBadge = 'bg-[#F0FDF4] text-[#15803D]';
                if (ev.category === 'Food') categoryBadge = 'bg-[#FFFBEB] text-[#B45309]';
                if (ev.category === 'Sports') categoryBadge = 'bg-[#F0FDF4] text-[#15803D]';
                if (ev.category === 'Kids') categoryBadge = 'bg-[#EEF2FF] text-[#4338CA]';

                return (
                  <tr
                    key={ev.id}
                    className={`hover:bg-[#fcf2eb]/50 transition-colors ${
                      !isActive ? 'bg-[#fcf2eb]/30' : ''
                    }`}
                  >
                    {/* Event & Category */}
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-lg overflow-hidden shrink-0 shadow-xs relative bg-[#f6ece6]">
                          <img
                            src={ev.imageUrl}
                            alt={ev.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div>
                          <div className="text-sm font-bold text-[#1f1b17] tracking-tight">
                            {ev.title}
                          </div>
                          <div className="flex items-center gap-2 mt-1">
                            <span className={`px-2 py-0.5 rounded-full font-semibold text-[11px] ${categoryBadge}`}>
                              {ev.category}
                            </span>
                            <span className="text-[11px] text-[#464555]">
                              {ev.attendeesCount > 0
                                ? `${ev.attendeesCount} Confirmed`
                                : 'Draft • Unpublished'}
                            </span>
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* City & Venue */}
                    <td className="py-4 px-4">
                      <div className="font-semibold text-[#1f1b17]">
                        {ev.neighborhood ? ev.neighborhood.split(',')[0] : ev.city}
                      </div>
                      <div className="text-[11px] text-[#464555] truncate max-w-[180px]">
                        {ev.venue}
                      </div>
                    </td>

                    {/* Date & Schedule */}
                    <td className="py-4 px-4">
                      <div className="font-semibold text-[#1f1b17]">{ev.dateTime.split('•')[0] || ev.dateTime}</div>
                      <div className="text-[11px] text-[#464555]">
                        {ev.dateTime.includes('•') ? ev.dateTime.split('•')[1] : '07:30 PM IST'}
                      </div>
                    </td>

                    {/* Price */}
                    <td className="py-4 px-4 font-bold text-[#1f1b17]">
                      {ev.isFree ? 'Free' : `₹${ev.price.toLocaleString()}`}
                    </td>

                    {/* Public Status Toggle */}
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-2.5">
                        <button
                          type="button"
                          role="switch"
                          aria-checked={isActive}
                          onClick={() => onToggleStatus(ev.id)}
                          className={`w-9 h-5 rounded-full transition-colors relative flex items-center p-0.5 cursor-pointer ${
                            isActive ? 'bg-emerald-600' : 'bg-[#ccc5c2]'
                          }`}
                        >
                          <div
                            className={`w-4 h-4 rounded-full bg-white transition-transform shadow-xs ${
                              isActive ? 'translate-x-4' : 'translate-x-0'
                            }`}
                          />
                        </button>

                        <span
                          className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full font-semibold text-[11px] ${
                            isActive
                              ? 'bg-emerald-50 text-emerald-700'
                              : 'bg-[#e9e1dd] text-[#625d5b]'
                          }`}
                        >
                          <span
                            className={`w-1.5 h-1.5 rounded-full ${
                              isActive ? 'bg-emerald-600 animate-pulse' : 'bg-[#625d5b]'
                            }`}
                          />
                          {isActive ? 'Active' : 'Inactive'}
                        </span>
                      </div>
                    </td>

                    {/* Actions */}
                    <td className="py-4 px-6 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => handleOpenEditDrawer(ev)}
                          title="Edit Event"
                          className="p-1.5 rounded-md hover:bg-[#f6ece6] text-[#464555] hover:text-[#1f1b17] transition-colors cursor-pointer"
                        >
                          <span className="material-symbols-outlined text-[18px]">
                            edit
                          </span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onDesignPass(ev.id)}
                          title="Preview Public Card"
                          className="p-1.5 rounded-md hover:bg-[#f6ece6] text-[#464555] hover:text-[#1f1b17] transition-colors cursor-pointer"
                        >
                          <span className="material-symbols-outlined text-[18px]">
                            visibility
                          </span>
                        </button>
                        {!isActive ? (
                          <button
                            type="button"
                            onClick={() => onToggleStatus(ev.id)}
                            className="px-2 py-1 rounded bg-[#3525cd]/10 hover:bg-[#3525cd]/20 text-[#3525cd] font-semibold text-[11px] transition-colors"
                          >
                            Publish
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => onArchiveEvent(ev.id)}
                            title="Archive Event"
                            className="p-1.5 rounded-md hover:bg-[#f6ece6] text-[#464555] hover:text-[#ba1a1a] transition-colors cursor-pointer"
                          >
                            <span className="material-symbols-outlined text-[18px]">
                              archive
                            </span>
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Table Footnote & State Bar */}
        <div className="px-6 py-4 bg-[#fcf2eb]/70 border-t border-[#eae1da] flex flex-col sm:flex-row items-center justify-between text-[#464555] text-xs gap-3">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[16px] text-[#005338]">
              verified_user
            </span>
            <span>
              Admin identity authenticated:{' '}
              <strong className="text-[#1f1b17] font-semibold">curator@civic.blr</strong>
            </span>
          </div>
          <div className="flex items-center gap-4">
            <span>
              Showing {filteredEvents.length} of {events.length} events
            </span>
            <div className="flex gap-1.5">
              <button
                type="button"
                disabled
                className="px-2.5 py-1 rounded bg-[#f6ece6] text-[#777587] opacity-60 text-xs"
              >
                Previous
              </button>
              <button
                type="button"
                className="px-2.5 py-1 rounded bg-[#f6ece6] hover:bg-[#f0e6e0] text-[#1f1b17] text-xs"
              >
                Next
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mini Analytics Metric Strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
        <div className="p-4 rounded-xl bg-white shadow-sm border border-[#eae1da] flex items-center justify-between">
          <div>
            <div className="text-xs text-[#464555] uppercase font-bold tracking-wider">
              Active Discoverability
            </div>
            <div className="text-2xl font-bold text-[#1f1b17] mt-1">78.5%</div>
            <div className="text-xs text-[#005338] font-semibold mt-0.5">
              High discovery ranking
            </div>
          </div>
          <div className="w-10 h-10 rounded-lg bg-[#005338]/10 text-[#005338] flex items-center justify-center">
            <span className="material-symbols-outlined text-[20px]">trending_up</span>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-white shadow-sm border border-[#eae1da] flex items-center justify-between">
          <div>
            <div className="text-xs text-[#464555] uppercase font-bold tracking-wider">
              Moderation Queue
            </div>
            <div className="text-2xl font-bold text-[#1f1b17] mt-1">0 Pending</div>
            <div className="text-xs text-[#464555] mt-0.5">
              All community submissions processed
            </div>
          </div>
          <div className="w-10 h-10 rounded-lg bg-[#3525cd]/10 text-[#3525cd] flex items-center justify-center">
            <span className="material-symbols-outlined text-[20px]">task_alt</span>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-white shadow-sm border border-[#eae1da] flex items-center justify-between">
          <div>
            <div className="text-xs text-[#464555] uppercase font-bold tracking-wider">
              Total Ticket Value
            </div>
            <div className="text-2xl font-bold text-[#1f1b17] mt-1">₹4,28,400</div>
            <div className="text-xs text-[#464555] mt-0.5">Direct to community hosts</div>
          </div>
          <div className="w-10 h-10 rounded-lg bg-[#f6ece6] text-[#1f1b17] flex items-center justify-center">
            <span className="material-symbols-outlined text-[20px]">currency_rupee</span>
          </div>
        </div>
      </div>

      {/* Slide-Over Drawer Form Modal for Add/Edit Event */}
      {isDrawerOpen && (
        <div className="fixed inset-0 bg-[#342f2b]/40 backdrop-blur-xs z-50 flex justify-end animate-in fade-in duration-200">
          <div className="w-full max-w-xl bg-white shadow-2xl flex flex-col h-full border-l border-[#eae1da] animate-in slide-in-from-right duration-300">
            {/* Drawer Header */}
            <div className="p-6 bg-[#fcf2eb] border-b border-[#eae1da] flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-[#1f1b17]">
                  {editingEventId ? `Edit Event: ${formTitle}` : 'Add New Community Event'}
                </h2>
                <p className="text-xs text-[#464555] mt-0.5">
                  Configure event details and discovery visibility status
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsDrawerOpen(false)}
                className="w-8 h-8 rounded-full bg-[#f6ece6] hover:bg-[#f0e6e0] text-[#464555] flex items-center justify-center transition-colors"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>

            {/* Drawer Form Body */}
            <form onSubmit={handleFormSubmit} className="flex-1 overflow-y-auto p-6 space-y-4">
              {/* Title */}
              <div className="space-y-1">
                <label className="block text-xs font-semibold text-[#1f1b17]">
                  Event Title <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="e.g. Sourdough Baking Masterclass"
                  className="w-full px-3 py-2 rounded-lg bg-[#fcf2eb] border border-[#eae1da] text-sm text-[#1f1b17] focus:outline-none focus:ring-2 focus:ring-[#3525cd]/20"
                />
              </div>

              {/* Category & City */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="block text-xs font-semibold text-[#1f1b17]">
                    Category <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as EventCategory)}
                    className="w-full px-3 py-2 rounded-lg bg-[#fcf2eb] border border-[#eae1da] text-sm text-[#1f1b17] focus:outline-none"
                  >
                    <option value="Music">Music & Acoustic</option>
                    <option value="Workshop">Workshop & Craft</option>
                    <option value="Food">Food & Heritage</option>
                    <option value="Sports">Sports & Fitness</option>
                    <option value="Kids">Kids & Family</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-semibold text-[#1f1b17]">City</label>
                  <select
                    value={formCity}
                    onChange={(e) => setFormCity(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-[#fcf2eb] border border-[#eae1da] text-sm text-[#1f1b17] focus:outline-none"
                  >
                    <option value="Bengaluru">Bengaluru, KA</option>
                    <option value="Mumbai">Mumbai, MH</option>
                    <option value="Delhi NCR">Delhi NCR</option>
                    <option value="Hyderabad">Hyderabad, TS</option>
                    <option value="Pune">Pune, MH</option>
                  </select>
                </div>
              </div>

              {/* Venue */}
              <div className="space-y-1">
                <label className="block text-xs font-semibold text-[#1f1b17]">
                  Venue Address & Neighborhood <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formVenue}
                  onChange={(e) => setFormVenue(e.target.value)}
                  placeholder="Hall name, Street, Neighborhood"
                  className="w-full px-3 py-2 rounded-lg bg-[#fcf2eb] border border-[#eae1da] text-sm text-[#1f1b17] focus:outline-none"
                />
              </div>

              {/* Date & Time and Price */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="block text-xs font-semibold text-[#1f1b17]">
                    Date & Schedule <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formDateTime}
                    onChange={(e) => setFormDateTime(e.target.value)}
                    placeholder="Sat, Mar 29 • 6:30 PM IST"
                    className="w-full px-3 py-2 rounded-lg bg-[#fcf2eb] border border-[#eae1da] text-sm text-[#1f1b17] focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="block text-xs font-semibold text-[#1f1b17]">
                      Ticket Price (₹)
                    </label>
                    <label className="inline-flex items-center gap-1 text-[11px] text-[#464555] cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formIsFree}
                        onChange={(e) => setFormIsFree(e.target.checked)}
                        className="rounded text-[#3525cd] accent-[#3525cd]"
                      />
                      Free
                    </label>
                  </div>
                  <div className="relative">
                    <span className="absolute left-3 top-2 text-sm text-[#777587]">₹</span>
                    <input
                      type="number"
                      disabled={formIsFree}
                      value={formIsFree ? 0 : formPrice}
                      onChange={(e) => setFormPrice(Number(e.target.value))}
                      className="w-full pl-7 pr-3 py-2 rounded-lg bg-[#fcf2eb] border border-[#eae1da] text-sm text-[#1f1b17] focus:outline-none disabled:opacity-50"
                    />
                  </div>
                </div>
              </div>

              {/* Cover Image URL & Preview */}
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-[#1f1b17]">
                  Cover Image URL
                </label>
                <div className="flex items-center gap-4">
                  <div className="w-20 h-20 rounded-lg overflow-hidden bg-[#f6ece6] shrink-0 border border-[#eae1da]">
                    <img
                      src={formImageUrl}
                      alt="Cover Preview"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 space-y-1">
                    <input
                      type="text"
                      value={formImageUrl}
                      onChange={(e) => setFormImageUrl(e.target.value)}
                      placeholder="https://images.unsplash.com/..."
                      className="w-full px-3 py-1.5 rounded-lg bg-[#fcf2eb] border border-[#eae1da] text-xs text-[#1f1b17] focus:outline-none"
                    />
                    <p className="text-[11px] text-[#464555]">
                      High-resolution cover URL (landscape ratio recommended).
                    </p>
                  </div>
                </div>
              </div>

              {/* Description */}
              <div className="space-y-1">
                <label className="block text-xs font-semibold text-[#1f1b17]">
                  Short Description <span className="text-red-500">*</span>
                </label>
                <textarea
                  required
                  rows={3}
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="Briefly describe what attendees will experience..."
                  className="w-full px-3 py-2 rounded-lg bg-[#fcf2eb] border border-[#eae1da] text-sm text-[#1f1b17] focus:outline-none resize-none"
                />
              </div>

              {/* Status Switch */}
              <div className="p-4 rounded-xl bg-[#fcf2eb] border border-[#eae1da] flex items-center justify-between">
                <div>
                  <span className="text-xs font-semibold text-[#1f1b17] block">
                    Public Discovery Status
                  </span>
                  <span className="text-[11px] text-[#464555] block">
                    Active events appear immediately in Public Discovery and My Feed.
                  </span>
                </div>
                <button
                  type="button"
                  role="switch"
                  aria-checked={formIsActive}
                  onClick={() => setFormIsActive(!formIsActive)}
                  className={`w-10 h-6 rounded-full transition-colors relative flex items-center p-0.5 cursor-pointer shrink-0 ${
                    formIsActive ? 'bg-emerald-600' : 'bg-[#ccc5c2]'
                  }`}
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-white transition-transform shadow-xs ${
                      formIsActive ? 'translate-x-4' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Notice */}
              <div className="p-3.5 rounded-xl bg-[#ffdad6]/40 border border-[#ffdad6] flex items-start gap-2.5 text-[#93000a] text-xs">
                <span className="material-symbols-outlined text-[18px] text-[#ba1a1a] shrink-0 mt-0.5">
                  info
                </span>
                <p className="leading-relaxed">
                  <strong>Notice:</strong> Deactivating an event hides it from discovery without deleting attendee registrations. Existing ticket holders retain access to their pass vouchers.
                </p>
              </div>

              {/* Drawer Footer Actions */}
              <div className="pt-4 flex items-center justify-between border-t border-[#eae1da]">
                <div className="text-xs text-[#464555] flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#005338]"></span>
                  <span>Curator session verified</span>
                </div>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setIsDrawerOpen(false)}
                    className="px-4 py-2 rounded-lg bg-[#f6ece6] hover:bg-[#f0e6e0] text-[#1f1b17] text-xs font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-lg bg-[#3525cd] hover:bg-[#4f46e5] text-white text-xs font-semibold shadow-md active:scale-95"
                  >
                    Save Event
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
