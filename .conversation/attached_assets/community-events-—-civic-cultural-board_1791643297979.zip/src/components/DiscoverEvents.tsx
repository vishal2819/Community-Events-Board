import React, { useState, useMemo } from 'react';
import { EventItem, EventCategory } from '../types';

interface DiscoverEventsProps {
  events: EventItem[];
  selectedCity: string;
  onSelectCity: (city: string) => void;
  onSelectEventForDesign: (event: EventItem) => void;
  onRsvpClick: (event: EventItem) => void;
  onShowToast: (title: string, desc: string) => void;
  reminders: Record<string, boolean>;
  onToggleReminder: (eventId: string, title: string) => void;
}

export const DiscoverEvents: React.FC<DiscoverEventsProps> = ({
  events,
  selectedCity,
  onSelectCity,
  onSelectEventForDesign,
  onRsvpClick,
  onShowToast,
  reminders,
  onToggleReminder
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('soonest');
  const [previewStateCycle, setPreviewStateCycle] = useState<number>(0); // 0: normal, 1: skeleton, 2: empty
  const [currentPage, setCurrentPage] = useState<number>(1);

  // Active events only in discovery
  const publicEvents = useMemo(() => {
    return events.filter((e) => e.status === 'active');
  }, [events]);

  // Dynamic category counts
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {
      all: publicEvents.length,
      music: 0,
      workshop: 0,
      food: 0,
      sports: 0,
      kids: 0
    };
    publicEvents.forEach((ev) => {
      const catKey = ev.category.toLowerCase();
      if (counts[catKey] !== undefined) {
        counts[catKey]++;
      }
    });
    return counts;
  }, [publicEvents]);

  // Filtered & sorted events
  const filteredEvents = useMemo(() => {
    return publicEvents
      .filter((ev) => {
        // Category filter
        if (activeCategory !== 'all' && ev.category.toLowerCase() !== activeCategory.toLowerCase()) {
          return false;
        }
        // City filter
        if (selectedCity && ev.city !== selectedCity) {
          // If in mock only Bengaluru is present, allow showing all if none match, but filter if city matches
          const cityMatches = ev.city.toLowerCase() === selectedCity.toLowerCase() || ev.neighborhood.toLowerCase().includes(selectedCity.toLowerCase());
          if (!cityMatches && selectedCity !== 'Bengaluru') {
            return false;
          }
        }
        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchTitle = ev.title.toLowerCase().includes(q);
          const matchVenue = ev.venue.toLowerCase().includes(q) || ev.neighborhood.toLowerCase().includes(q);
          const matchCat = ev.category.toLowerCase().includes(q);
          if (!matchTitle && !matchVenue && !matchCat) return false;
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'price-low') {
          return a.price - b.price;
        }
        if (sortBy === 'price-high') {
          return b.price - a.price;
        }
        if (sortBy === 'popular') {
          return b.attendeesCount - a.attendeesCount;
        }
        return 0; // soonest
      });
  }, [publicEvents, activeCategory, selectedCity, searchQuery, sortBy]);

  const itemsPerPage = 6;
  const paginatedEvents = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredEvents.slice(start, start + itemsPerPage);
  }, [filteredEvents, currentPage]);

  const handleResetFilters = () => {
    setSearchQuery('');
    setActiveCategory('all');
    setSortBy('soonest');
    onSelectCity('Bengaluru');
    setPreviewStateCycle(0);
    setCurrentPage(1);
    onShowToast('Filters cleared', 'Showing all upcoming community events in Bengaluru.');
  };

  const handleToggleStatePreview = () => {
    const nextState = (previewStateCycle + 1) % 3;
    setPreviewStateCycle(nextState);
    if (nextState === 1) {
      onShowToast('Simulating: Skeleton Loading', 'Demonstrating content placeholder loading wave.');
    } else if (nextState === 2) {
      onShowToast('Simulating: Empty Search State', 'Demonstrating zero results state with CTA.');
    } else {
      onShowToast('State: Live Event Grid', 'Returned to standard interactive discovery board.');
    }
  };

  return (
    <div className="flex flex-col w-full">
      {/* Hero Header Section */}
      <section className="relative w-full px-4 md:px-8 pt-8 pb-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="flex flex-col gap-1 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#e9e1dd] text-[#4a4643] self-start shadow-sm">
              <span className="w-2 h-2 rounded-full bg-[#005338] animate-pulse"></span>
              <span className="text-xs font-semibold tracking-wide">
                18 events this weekend • Live in {selectedCity}
              </span>
            </div>
            <h1 className="text-3xl md:text-5xl font-bold text-[#1f1b17] tracking-tight mt-2">
              Local happenings, curated for you.
            </h1>
            <p className="text-base md:text-lg text-[#464555] max-w-2xl mt-1">
              Explore upcoming gatherings, workshops, live concerts, and neighborhood meetups across your city.
            </p>
          </div>

          {/* Quick Highlights Meta Card */}
          <div className="flex items-center gap-4 bg-[#fcf2eb] p-4 rounded-xl shadow-sm border border-[#eae1da]/60 self-start md:self-auto">
            <div className="w-12 h-12 rounded-lg bg-[#3525cd]/10 flex items-center justify-center text-[#3525cd]">
              <span className="material-symbols-outlined text-[26px]">
                local_activity
              </span>
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-bold text-[#1f1b17]">1,240+</span>
              <span className="text-xs text-[#464555]">
                Community RSVPs recorded this week
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Sticky / Composable Filters Toolbar */}
      <section className="w-full px-4 md:px-8 pb-6">
        <div className="max-w-7xl mx-auto flex flex-col gap-4">
          {/* Search, City & Sort Bar */}
          <div className="bg-white p-3 md:p-4 rounded-xl shadow-sm border border-[#eae1da]/80 flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
            {/* Search Input */}
            <div className="relative flex-1 flex items-center">
              <span className="material-symbols-outlined absolute left-3 text-[#777587] text-[20px] pointer-events-none">
                search
              </span>
              <input
                id="event-search-input"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search events by title, artist, or venue..."
                className="w-full h-10 pl-10 pr-10 bg-[#fcf2eb] rounded-lg text-sm text-[#1f1b17] placeholder:text-[#777587] focus:outline-none focus:bg-white focus:ring-2 focus:ring-[#3525cd]/20 transition-all border border-[#eae1da]/50"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  title="Clear search"
                  className="absolute right-3 text-[#777587] hover:text-[#1f1b17]"
                >
                  <span className="material-symbols-outlined text-[18px]">
                    cancel
                  </span>
                </button>
              )}
            </div>

            {/* Filter Controls Dropdowns */}
            <div className="flex items-center flex-wrap sm:flex-nowrap gap-2 sm:gap-3">
              {/* City Dropdown */}
              <div className="relative min-w-[150px] flex-1 sm:flex-initial">
                <div className="flex items-center gap-1.5 px-3 h-10 rounded-lg bg-[#fcf2eb] text-[#1f1b17] border border-[#eae1da]/50">
                  <span className="material-symbols-outlined text-[#3525cd] text-[18px]">
                    location_on
                  </span>
                  <select
                    id="city-selector"
                    value={selectedCity}
                    onChange={(e) => onSelectCity(e.target.value)}
                    className="w-full bg-transparent text-sm font-medium text-[#1f1b17] focus:outline-none cursor-pointer"
                  >
                    <option value="Bengaluru">Bengaluru</option>
                    <option value="Mumbai">Mumbai</option>
                    <option value="Delhi NCR">Delhi NCR</option>
                    <option value="Hyderabad">Hyderabad</option>
                    <option value="Pune">Pune</option>
                  </select>
                </div>
              </div>

              {/* Sort Dropdown */}
              <div className="relative min-w-[170px] flex-1 sm:flex-initial">
                <div className="flex items-center gap-1.5 px-3 h-10 rounded-lg bg-[#fcf2eb] text-[#1f1b17] border border-[#eae1da]/50">
                  <span className="material-symbols-outlined text-[#464555] text-[18px]">
                    sort
                  </span>
                  <select
                    id="sort-selector"
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="w-full bg-transparent text-sm font-medium text-[#1f1b17] focus:outline-none cursor-pointer"
                  >
                    <option value="soonest">Upcoming soonest</option>
                    <option value="price-low">Price: Low to High</option>
                    <option value="price-high">Price: High to Low</option>
                    <option value="popular">Most Popular</option>
                  </select>
                </div>
              </div>

              {/* Quick State Toggle / Developer Mode button */}
              <button
                type="button"
                onClick={handleToggleStatePreview}
                title="Toggle Demo Mockups: Empty & Skeleton States"
                className="h-10 px-3 rounded-lg bg-[#f6ece6] hover:bg-[#f0e6e0] text-[#464555] hover:text-[#1f1b17] text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer border border-[#eae1da]/60"
              >
                <span className="material-symbols-outlined text-[18px]">tune</span>
                <span className="hidden xl:inline">Simulate States</span>
              </button>
            </div>
          </div>

          {/* Category Filter Pills & Summary Counter Bar */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="flex items-center gap-2 overflow-x-auto py-1 scrollbar-none">
              {[
                { key: 'all', label: `All (${categoryCounts.all})` },
                { key: 'music', label: `Music (${categoryCounts.music})` },
                { key: 'workshop', label: `Workshop (${categoryCounts.workshop})` },
                { key: 'food', label: `Food (${categoryCounts.food})` },
                { key: 'sports', label: `Sports (${categoryCounts.sports})` },
                { key: 'kids', label: `Kids (${categoryCounts.kids})` }
              ].map((cat) => {
                const isActive = activeCategory === cat.key;
                return (
                  <button
                    key={cat.key}
                    type="button"
                    onClick={() => {
                      setActiveCategory(cat.key);
                      setCurrentPage(1);
                    }}
                    className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all shadow-sm cursor-pointer whitespace-nowrap ${
                      isActive
                        ? 'bg-[#3525cd] text-white shadow-sm'
                        : 'bg-[#fcf2eb] text-[#464555] hover:bg-[#f6ece6] hover:text-[#1f1b17] border border-[#eae1da]/60'
                    }`}
                  >
                    {cat.label}
                  </button>
                );
              })}
            </div>

            <div className="flex items-center justify-between md:justify-end gap-4">
              <span className="text-sm text-[#464555]">
                Showing{' '}
                <strong className="text-[#1f1b17] font-semibold">
                  {previewStateCycle === 2 ? 0 : paginatedEvents.length}
                </strong>{' '}
                of{' '}
                <strong className="text-[#1f1b17] font-semibold">
                  {filteredEvents.length}
                </strong>{' '}
                events
              </span>
              <button
                type="button"
                onClick={handleResetFilters}
                className="text-xs font-semibold text-[#3525cd] hover:text-[#0f0069] flex items-center gap-1 transition-colors cursor-pointer"
              >
                <span className="material-symbols-outlined text-[16px]">
                  restart_alt
                </span>
                Reset filters
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content Showcase */}
      <section className="w-full px-4 md:px-8 pb-12">
        <div className="max-w-7xl mx-auto">
          {/* SKELETON STATE SIMULATION */}
          {previewStateCycle === 1 && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-pulse">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div
                  key={i}
                  className="flex flex-col bg-white rounded-xl overflow-hidden shadow-sm border border-[#eae1da]"
                >
                  <div className="aspect-[16/10] bg-[#f0e6e0]" />
                  <div className="p-4 flex flex-col gap-3">
                    <div className="h-4 w-1/3 bg-[#f0e6e0] rounded" />
                    <div className="h-6 w-3/4 bg-[#f0e6e0] rounded" />
                    <div className="h-4 w-1/2 bg-[#f0e6e0] rounded" />
                    <div className="mt-4 pt-3 border-t border-[#f0e6e0] flex justify-between items-center">
                      <div className="h-6 w-1/4 bg-[#f0e6e0] rounded" />
                      <div className="h-8 w-20 bg-[#f0e6e0] rounded-lg" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* EMPTY SEARCH STATE SIMULATION / ZERO RESULTS */}
          {(previewStateCycle === 2 || (previewStateCycle === 0 && paginatedEvents.length === 0)) && (
            <div className="flex flex-col items-center justify-center text-center py-20 px-4 bg-white rounded-2xl shadow-sm border border-[#eae1da]">
              <div className="w-16 h-16 rounded-full bg-[#f0e6e0] flex items-center justify-center text-[#777587] mb-4">
                <span className="material-symbols-outlined text-[32px]">
                  event_busy
                </span>
              </div>
              <h3 className="text-xl md:text-2xl font-bold text-[#1f1b17] tracking-tight">
                No events found matching your criteria
              </h3>
              <p className="text-sm md:text-base text-[#464555] max-w-md mt-2">
                Try expanding your search query, selecting different categories, or clearing active filters.
              </p>
              <button
                type="button"
                onClick={handleResetFilters}
                className="mt-6 px-6 py-2.5 rounded-lg bg-[#3525cd] text-white text-sm font-semibold shadow-sm hover:bg-[#4f46e5] transition-colors inline-flex items-center gap-2 cursor-pointer"
              >
                <span className="material-symbols-outlined text-[18px]">
                  filter_alt_off
                </span>
                Clear all filters
              </button>
            </div>
          )}

          {/* LIVE EVENT GRID VIEW */}
          {previewStateCycle === 0 && paginatedEvents.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {paginatedEvents.map((event) => {
                const isReminderSet = reminders[event.id] || false;

                // Category pill color themes matching mockup
                let badgeClass = 'bg-[#e2dfff] text-[#0f0069]';
                if (event.category === 'Workshop') {
                  badgeClass = 'bg-[#e9e1dd] text-[#1e1b19]';
                } else if (event.category === 'Food') {
                  badgeClass = 'bg-[#f0e6e0] text-[#464555]';
                } else if (event.category === 'Sports') {
                  badgeClass = 'bg-[#85f8c4] text-[#002114]';
                } else if (event.category === 'Kids') {
                  badgeClass = 'bg-[#e9e1dd] text-[#1e1b19]';
                }

                return (
                  <article
                    key={event.id}
                    className="group flex flex-col bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-200 border border-[#eae1da]/70"
                  >
                    {/* Image Banner & Overlay Badges */}
                    <div className="relative w-full aspect-[16/10] overflow-hidden bg-[#f6ece6]">
                      <img
                        src={event.imageUrl}
                        alt={event.imageAlt || event.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        loading="lazy"
                      />
                      <div className="absolute top-3 left-3">
                        <span
                          className={`px-3 py-0.5 rounded-full text-xs font-semibold shadow-sm ${badgeClass}`}
                        >
                          {event.category}
                        </span>
                      </div>

                      {/* Reminder Button */}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleReminder(event.id, event.title);
                        }}
                        title={isReminderSet ? 'Cancel reminder' : 'Set reminder'}
                        className={`absolute top-3 right-3 w-9 h-9 rounded-full backdrop-blur-sm flex items-center justify-center shadow-md transition-all cursor-pointer ${
                          isReminderSet
                            ? 'bg-[#3525cd] text-white'
                            : 'bg-white/90 text-[#1f1b17] hover:text-[#3525cd]'
                        }`}
                      >
                        <span
                          className="material-symbols-outlined text-[20px]"
                          style={{
                            fontVariationSettings: isReminderSet ? "'FILL' 1" : "'FILL' 0"
                          }}
                        >
                          {isReminderSet ? 'notifications_active' : 'notifications_none'}
                        </span>
                      </button>
                    </div>

                    {/* Card Body */}
                    <div className="p-4 flex-1 flex flex-col justify-between gap-4">
                      <div className="flex flex-col gap-1">
                        <div className="flex items-center gap-1.5 text-xs text-[#3525cd] font-semibold">
                          <span className="material-symbols-outlined text-[16px]">
                            calendar_month
                          </span>
                          <span>{event.dateTime}</span>
                        </div>
                        <h3
                          onClick={() => onSelectEventForDesign(event)}
                          className="text-lg font-bold text-[#1f1b17] tracking-tight group-hover:text-[#3525cd] transition-colors cursor-pointer line-clamp-2 mt-0.5"
                        >
                          {event.title}
                        </h3>
                        <div className="flex items-center gap-1 text-xs text-[#464555] mt-0.5">
                          <span className="material-symbols-outlined text-[16px] text-[#777587]">
                            location_on
                          </span>
                          <span>{event.neighborhood}</span>
                        </div>
                      </div>

                      {/* Card Footer Bar */}
                      <div className="pt-2 bg-[#fcf2eb]/60 -mx-4 -mb-4 p-4 flex items-center justify-between mt-auto border-t border-[#eae1da]/50">
                        {/* Left metadata: Avatars or Spots left or Custom tag */}
                        <div className="flex items-center gap-1.5">
                          {event.spotsLeft !== undefined ? (
                            <span className="inline-flex items-center gap-1 text-xs text-[#ba1a1a] font-semibold bg-[#ffdad6]/60 px-2.5 py-0.5 rounded-full">
                              <span className="w-1.5 h-1.5 rounded-full bg-[#ba1a1a]"></span>
                              {event.spotsLeft} spots left
                            </span>
                          ) : event.badgeNote ? (
                            <span
                              className={`text-xs font-semibold ${
                                event.category === 'Sports'
                                  ? 'text-[#005338] uppercase tracking-wider'
                                  : 'text-[#464555]'
                              }`}
                            >
                              {event.badgeNote}
                            </span>
                          ) : (
                            <div className="flex items-center gap-2">
                              <div className="flex -space-x-2 overflow-hidden">
                                <div className="inline-block h-6 w-6 rounded-full ring-2 ring-white bg-[#f6ece6] flex items-center justify-center text-[10px] text-[#464555] font-semibold">
                                  A
                                </div>
                                <div className="inline-block h-6 w-6 rounded-full ring-2 ring-white bg-[#e2dfff] flex items-center justify-center text-[10px] text-[#0f0069] font-semibold">
                                  R
                                </div>
                                <div className="inline-block h-6 w-6 rounded-full ring-2 ring-white bg-[#e9e1dd] flex items-center justify-center text-[10px] text-[#686361] font-semibold">
                                  S
                                </div>
                              </div>
                              <span className="text-xs text-[#464555] font-medium">
                                {event.attendeesCount} attending
                              </span>
                            </div>
                          )}
                        </div>

                        {/* Price & Action Button */}
                        <div className="flex items-center gap-3">
                          <span
                            className={`text-base font-bold ${
                              event.isFree ? 'text-[#005338]' : 'text-[#1f1b17]'
                            }`}
                          >
                            {event.isFree ? 'Free' : `₹${event.price.toLocaleString()}`}
                          </span>
                          <button
                            type="button"
                            onClick={() => onRsvpClick(event)}
                            className="px-4 py-1.5 rounded-lg bg-[#3525cd] hover:bg-[#4f46e5] text-white text-xs font-semibold shadow-sm transition-all active:scale-95 cursor-pointer"
                          >
                            {event.isFree ? 'Join Run' : 'RSVP'}
                          </button>
                        </div>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}

          {/* Pagination Toolbar */}
          <div
            id="pagination-bar"
            className="mt-8 pt-4 flex flex-col sm:flex-row items-center justify-between gap-4 bg-[#fcf2eb] p-4 rounded-xl shadow-sm border border-[#eae1da]/60"
          >
            <span className="text-xs text-[#464555]">
              Showing{' '}
              <strong className="text-[#1f1b17] font-semibold">
                {paginatedEvents.length > 0 ? 1 : 0}–{paginatedEvents.length}
              </strong>{' '}
              of{' '}
              <strong className="text-[#1f1b17] font-semibold">
                {filteredEvents.length}
              </strong>{' '}
              results
            </span>
            <div className="flex items-center gap-1.5">
              {/* Previous */}
              <button
                type="button"
                disabled={currentPage <= 1}
                onClick={() => {
                  setCurrentPage((p) => Math.max(1, p - 1));
                  onShowToast('Page updated', 'Loaded previous event batch.');
                }}
                className="h-9 px-3 rounded-lg text-[#777587] bg-white/60 border border-[#eae1da] cursor-pointer disabled:cursor-not-allowed disabled:opacity-40 text-xs font-medium flex items-center gap-1"
              >
                <span className="material-symbols-outlined text-[18px]">
                  chevron_left
                </span>
                <span className="hidden sm:inline">Previous</span>
              </button>

              {/* Page 1 */}
              <button
                type="button"
                onClick={() => setCurrentPage(1)}
                className={`w-9 h-9 rounded-lg text-xs font-semibold flex items-center justify-center transition-all ${
                  currentPage === 1
                    ? 'bg-[#3525cd] text-white shadow-sm'
                    : 'bg-white hover:bg-[#f6ece6] text-[#1f1b17] border border-[#eae1da]'
                }`}
              >
                1
              </button>

              {/* Page 2 */}
              <button
                type="button"
                onClick={() => {
                  setCurrentPage(2);
                  onShowToast('Page 2 loaded', 'Paginated listings refreshed with the latest civic data.');
                }}
                className={`w-9 h-9 rounded-lg text-xs font-semibold flex items-center justify-center transition-all ${
                  currentPage === 2
                    ? 'bg-[#3525cd] text-white shadow-sm'
                    : 'bg-white hover:bg-[#f6ece6] text-[#1f1b17] border border-[#eae1da]'
                }`}
              >
                2
              </button>

              {/* Page 3 */}
              <button
                type="button"
                onClick={() => {
                  setCurrentPage(3);
                  onShowToast('Page 3 loaded', 'Paginated listings refreshed with the latest civic data.');
                }}
                className={`w-9 h-9 rounded-lg text-xs font-semibold flex items-center justify-center transition-all ${
                  currentPage === 3
                    ? 'bg-[#3525cd] text-white shadow-sm'
                    : 'bg-white hover:bg-[#f6ece6] text-[#1f1b17] border border-[#eae1da]'
                }`}
              >
                3
              </button>

              {/* Next */}
              <button
                type="button"
                onClick={() => {
                  setCurrentPage((p) => p + 1);
                  onShowToast('Next page loaded', 'Paginated listings refreshed with the latest civic data.');
                }}
                className="h-9 px-3 rounded-lg text-[#1f1b17] bg-white hover:bg-[#f6ece6] border border-[#eae1da] text-xs font-medium flex items-center gap-1 transition-colors cursor-pointer"
              >
                <span className="hidden sm:inline">Next</span>
                <span className="material-symbols-outlined text-[18px]">
                  chevron_right
                </span>
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
