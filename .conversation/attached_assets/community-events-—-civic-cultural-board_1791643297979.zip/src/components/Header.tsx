import React, { useState } from 'react';
import { AppScreen } from '../types';

interface HeaderProps {
  currentScreen: AppScreen;
  onNavigate: (screen: AppScreen) => void;
  selectedCity: string;
  onSelectCity: (city: string) => void;
  userEmail?: string;
}

export const Header: React.FC<HeaderProps> = ({
  currentScreen,
  onNavigate,
  selectedCity,
  onSelectCity,
  userEmail
}) => {
  const [isCityOpen, setIsCityOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const cities = ['Bengaluru', 'Mumbai', 'Delhi NCR', 'Hyderabad', 'Pune'];

  const navItems: { label: string; screen: AppScreen }[] = [
    { label: 'Discover Events', screen: 'discover-events' },
    { label: 'My Feed', screen: 'my-feed' },
    { label: 'Favourite Categories', screen: 'favourite-categories' },
    { label: 'Card Designer', screen: 'card-designer' },
    { label: 'Admin Portal', screen: 'admin-portal' }
  ];

  return (
    <header className="fixed top-0 w-full z-50 bg-[#fff8f5]/90 backdrop-blur-md shadow-[0_1px_8px_rgba(0,0,0,0.04)] border-b border-[#eae1da]/60">
      <div className="h-16 max-w-7xl mx-auto px-4 md:px-8 flex items-center justify-between gap-6">
        {/* Brand Logo & Tag */}
        <div 
          className="flex items-center gap-2 cursor-pointer select-none"
          onClick={() => onNavigate('discover-events')}
        >
          <img
            alt="Community Events Board Logo"
            className="h-8 w-auto object-contain"
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuBXroeTkPxy6k2SsBH4edILl-iitMoZ3L5RLUhEuqE4EWEND1ABnL0OHm1F1DpvBplxGx7ZYhPpOIKawduahB0XALQhQCo-h8ah3tFX8Vf9uWtdkaEWa3HxrmP9wMCYohKPSkeOhEuqjdsRW_D_rvg58QpzM0LT9HwGQVGdLL01LagPvLSF3crloMIZ-k1rnOXGUV0Ay_IFFSpnEpJXPU36VbySsbfvlR4V83vMkHPLotd8v6sq7g0c"
          />
          <div className="flex items-center gap-1.5">
            <span className="font-semibold text-lg text-[#1f1b17] tracking-tight">
              Community Events
            </span>
            <span className="px-1.5 py-0.5 rounded-full bg-[#e9e1dd] text-[#686361] text-xs font-semibold uppercase tracking-wider">
              Civic
            </span>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-6">
          {navItems.map((item) => {
            const isActive = currentScreen === item.screen;
            return (
              <button
                key={item.screen}
                type="button"
                onClick={() => onNavigate(item.screen)}
                className={`text-sm transition-colors py-1 cursor-pointer font-medium relative ${
                  isActive
                    ? 'text-[#1f1b17] font-semibold'
                    : 'text-[#464555] hover:text-[#1f1b17]'
                }`}
              >
                {item.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#3525cd] rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Right Action Cluster */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* City Selector */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setIsCityOpen(!isCityOpen)}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#f6ece6] hover:bg-[#f0e6e0] text-[#464555] text-xs font-medium transition-colors"
            >
              <span className="material-symbols-outlined text-[16px] text-[#3525cd]">
                location_on
              </span>
              <span>{selectedCity}, IN</span>
              <span className="material-symbols-outlined text-[14px]">
                arrow_drop_down
              </span>
            </button>

            {isCityOpen && (
              <div className="absolute right-0 mt-2 w-40 bg-white rounded-xl shadow-lg border border-[#eae1da] py-1 z-50 animate-in fade-in zoom-in-95 duration-150">
                {cities.map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => {
                      onSelectCity(c);
                      setIsCityOpen(false);
                    }}
                    className={`w-full text-left px-3 py-2 text-xs transition-colors flex items-center justify-between ${
                      selectedCity === c
                        ? 'bg-[#e2dfff] text-[#0f0069] font-semibold'
                        : 'text-[#1f1b17] hover:bg-[#fcf2eb]'
                    }`}
                  >
                    <span>{c}</span>
                    {selectedCity === c && (
                      <span className="material-symbols-outlined text-[14px]">
                        check
                      </span>
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Sign In / Profile Switch */}
          {userEmail ? (
            <button
              type="button"
              onClick={() => onNavigate('sign-in')}
              className="px-3 py-1.5 rounded-lg bg-[#f6ece6] hover:bg-[#f0e6e0] text-[#1f1b17] text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <span className="w-2 h-2 rounded-full bg-[#005338]"></span>
              <span className="max-w-[100px] truncate">{userEmail.split('@')[0]}</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => onNavigate('sign-in')}
              className={`px-3 sm:px-4 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                currentScreen === 'sign-in'
                  ? 'bg-[#3525cd] text-white'
                  : 'bg-[#f6ece6] hover:bg-[#f0e6e0] text-[#1f1b17]'
              }`}
            >
              Sign In
            </button>
          )}

          {/* User Avatar Circle */}
          <button
            type="button"
            onClick={() => onNavigate('sign-in')}
            title="User Profile"
            className="w-8 h-8 rounded-full bg-[#3525cd] flex items-center justify-center text-white hover:bg-[#4f46e5] transition-colors shadow-sm"
          >
            <span className="material-symbols-outlined text-[18px]">person</span>
          </button>

          {/* Mobile Menu Hamburger */}
          <button
            type="button"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-1.5 rounded-lg text-[#1f1b17] hover:bg-[#f6ece6] transition-colors"
            aria-label="Toggle navigation menu"
          >
            <span className="material-symbols-outlined text-[24px]">
              {isMobileMenuOpen ? 'close' : 'menu'}
            </span>
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-[#fff8f5] border-t border-[#eae1da] px-4 py-4 space-y-2 shadow-xl">
          {navItems.map((item) => (
            <button
              key={item.screen}
              type="button"
              onClick={() => {
                onNavigate(item.screen);
                setIsMobileMenuOpen(false);
              }}
              className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium transition-colors flex items-center justify-between ${
                currentScreen === item.screen
                  ? 'bg-[#e2dfff] text-[#0f0069] font-semibold'
                  : 'text-[#464555] hover:bg-[#f6ece6]'
              }`}
            >
              <span>{item.label}</span>
              {currentScreen === item.screen && (
                <span className="material-symbols-outlined text-[16px]">
                  chevron_right
                </span>
              )}
            </button>
          ))}
          <div className="pt-2 border-t border-[#eae1da] flex items-center justify-between text-xs text-[#464555]">
            <span>Active City:</span>
            <select
              value={selectedCity}
              onChange={(e) => onSelectCity(e.target.value)}
              className="bg-[#f6ece6] px-2 py-1 rounded text-xs text-[#1f1b17]"
            >
              {cities.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
        </div>
      )}
    </header>
  );
};
