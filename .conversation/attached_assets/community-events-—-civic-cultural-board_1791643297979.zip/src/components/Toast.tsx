import React from 'react';
import { ToastMessage } from '../types';

interface ToastProps {
  toast: ToastMessage | null;
  onClose: () => void;
}

export const Toast: React.FC<ToastProps> = ({ toast, onClose }) => {
  if (!toast) return null;

  return (
    <div
      role="alert"
      className="fixed bottom-6 right-6 z-50 transform transition-all duration-300 ease-out flex items-center gap-3 bg-[#342f2b] text-[#f9efe8] px-4 py-3 rounded-xl shadow-2xl max-w-md border border-white/10 animate-in fade-in slide-in-from-bottom-5"
    >
      <span
        className="material-symbols-outlined text-[#85f8c4] text-[22px] shrink-0"
        style={{ fontVariationSettings: "'FILL' 1" }}
      >
        check_circle
      </span>
      <div className="flex flex-col min-w-0 pr-2">
        <span className="text-sm font-semibold text-white truncate">
          {toast.title}
        </span>
        <span className="text-xs text-[#eae1da] truncate">
          {toast.desc}
        </span>
      </div>
      <button
        type="button"
        onClick={onClose}
        className="ml-auto text-[#f9efe8]/70 hover:text-white p-1 rounded transition-colors"
        aria-label="Close notification"
      >
        <span className="material-symbols-outlined text-[18px]">close</span>
      </button>
    </div>
  );
};
