import React, { useState, useId } from 'react';
import { EventItem, StickerItem, CardDesignState, AppScreen } from '../types';
import { STICKER_CATALOG } from '../data/mockEvents';

interface CardDesignerProps {
  events: EventItem[];
  currentEventId: string;
  onSelectEvent: (id: string) => void;
  designState: CardDesignState;
  onUpdateDesign: (state: Partial<CardDesignState>) => void;
  onNavigate: (screen: AppScreen) => void;
  onShowToast: (title: string, desc: string) => void;
}

export const CardDesigner: React.FC<CardDesignerProps> = ({
  events,
  currentEventId,
  onSelectEvent,
  designState,
  onUpdateDesign,
  onNavigate,
  onShowToast
}) => {
  const [isSaving, setIsSaving] = useState(false);
  const [syncStatus, setSyncStatus] = useState('All changes saved to profile');
  const cardElementId = useId();

  // Find active event
  const activeEvent =
    events.find((e) => e.id === currentEventId) || events[0] || {
      id: 'evt-1',
      title: 'Bangalore Acoustic Evening & Vinyl Showcase',
      venue: 'The Teal House, 12th Main',
      neighborhood: 'Indiranagar Cultural Pavilion',
      dateTime: 'Sat, Oct 18 • 6:30 PM',
      imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCbToI9E56H6LEoyTrurj9HPSHNq05c5fOTBRl_A0COdyg7g-_Z02xnQuHuVmNbENKJ6vqizgvwPy7nLUtZp5HvgWeAzuxaHyVAD5Wxq0Zaj7Vkrb416O5uxou5edLvicnyKfGEF5oKGGDVtpK6QiYLJ0p1LiTzpMwqIxXcEgYrHZNQovBzxLIWK8-cpPNSY9u-NRfnRSa9SkW5cBSNNg7nQNy2ldvtU9nkzX5P37Vggozj9BYG2AQP'
    };

  const themes: Array<{
    id: 'warm-atelier' | 'indigo-midnight' | 'civic-emerald';
    name: string;
    sub: string;
    icon: string;
    iconBg: string;
  }> = [
    {
      id: 'warm-atelier',
      name: 'Warm Atelier',
      sub: 'Stone linen & soft charcoal',
      icon: 'texture',
      iconBg: 'bg-[#f6ece6] text-[#625d5b]'
    },
    {
      id: 'indigo-midnight',
      name: 'Indigo Midnight',
      sub: 'Deep navy gradient & bright ink',
      icon: 'dark_mode',
      iconBg: 'bg-[#3525cd] text-white'
    },
    {
      id: 'civic-emerald',
      name: 'Civic Emerald',
      sub: 'Botanical sage & deep forest',
      icon: 'park',
      iconBg: 'bg-[#006e4c] text-white'
    }
  ];

  const handleSelectTheme = (themeId: 'warm-atelier' | 'indigo-midnight' | 'civic-emerald') => {
    onUpdateDesign({ theme: themeId });
    setSyncStatus('Theme synced with profile');
  };

  const handleToggleSticker = (stickerId: string) => {
    const existingIndex = designState.stickers.findIndex((s) => s.id === stickerId);
    if (existingIndex > -1) {
      // Remove
      const updated = designState.stickers.filter((s) => s.id !== stickerId);
      onUpdateDesign({ stickers: updated });
    } else {
      // Add if under capacity (max 3)
      if (designState.stickers.length >= 3) {
        onShowToast('Maximum reached', 'Maximum 3 stickers allowed per keepsake pass.');
        return;
      }
      const item = STICKER_CATALOG[stickerId];
      if (item) {
        onUpdateDesign({ stickers: [...designState.stickers, item] });
      }
    }
    setSyncStatus('Stickers updated');
  };

  const handleRemoveSticker = (stickerId: string) => {
    const updated = designState.stickers.filter((s) => s.id !== stickerId);
    onUpdateDesign({ stickers: updated });
  };

  const handleSaveCard = () => {
    if (isSaving) return;
    setIsSaving(true);
    setSyncStatus('Synchronizing with ledger...');

    setTimeout(() => {
      setIsSaving(false);
      setSyncStatus('✓ All changes saved to your profile');
      onShowToast('Card personalized and saved!', 'Asset synchronized to your civic pass vault.');
    }, 1000);
  };

  const handleDownload = () => {
    // Generate clean printable ticket view or client PNG simulation
    onShowToast('High-Res Pass Ready', 'Opening high-definition keepsake preview for download.');
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto w-full px-4 md:px-8 py-8 md:py-12">
      {/* Editorial Breadcrumb & Header Unit */}
      <header className="mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="space-y-1 max-w-2xl">
          <nav aria-label="Breadcrumb" className="flex items-center gap-1.5 text-xs text-[#625d5b]">
            <button
              type="button"
              onClick={() => onNavigate('discover-events')}
              className="hover:text-[#1f1b17] transition-colors"
            >
              Events
            </button>
            <span className="text-[#c7c4d8]">/</span>
            <span className="hover:text-[#1f1b17] transition-colors truncate max-w-[200px]">
              {activeEvent.title}
            </span>
            <span className="text-[#c7c4d8]">/</span>
            <span className="text-[#3525cd] font-semibold">Card Designer</span>
          </nav>
          <h1 className="text-3xl md:text-4xl font-bold text-[#1f1b17] tracking-tight">
            Personalize Event Pass & Social Card
          </h1>
          <p className="text-sm text-[#625d5b]">
            Customize the collectible digital keepsake card with curated background themes and celebratory stickers.
          </p>
        </div>

        {/* Sync Status Badge */}
        <div className="flex items-center gap-2 self-start md:self-auto bg-[#f6ece6] px-4 py-1.5 rounded-full border border-[#eae1da]">
          <span className="inline-flex h-2 w-2 rounded-full bg-[#005338] animate-pulse"></span>
          <span className="text-xs font-semibold text-[#464555]">
            {syncStatus}
          </span>
        </div>
      </header>

      {/* Two-Column Bespoke Studio Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* LEFT: Controls & Configuration Panel (5 cols) */}
        <section aria-label="Customization Controls" className="lg:col-span-5 flex flex-col gap-6">
          {/* Active Event & Attendee Switcher */}
          <div className="bg-white p-5 rounded-xl shadow-sm border border-[#eae1da] space-y-3">
            <label className="block text-xs font-bold uppercase tracking-wider text-[#625d5b]">
              Pass Assigned To Event
            </label>
            <select
              value={activeEvent.id}
              onChange={(e) => onSelectEvent(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg bg-[#fcf2eb] border border-[#eae1da] text-[#1f1b17] font-medium focus:outline-none"
            >
              {events.map((ev) => (
                <option key={ev.id} value={ev.id}>
                  {ev.title} ({ev.category})
                </option>
              ))}
            </select>

            <div className="space-y-1 pt-1">
              <label className="block text-xs font-bold uppercase tracking-wider text-[#625d5b]">
                Passholder Name
              </label>
              <input
                type="text"
                value={designState.attendeeName}
                onChange={(e) => onUpdateDesign({ attendeeName: e.target.value })}
                placeholder="e.g. Arun K. Ramaswamy"
                className="w-full px-3 py-2 text-sm rounded-lg bg-[#fcf2eb] border border-[#eae1da] text-[#1f1b17] font-semibold focus:outline-none focus:ring-2 focus:ring-[#3525cd]/20"
              />
            </div>
          </div>

          {/* Section A: Theme Selector */}
          <div className="bg-white p-6 rounded-xl shadow-sm border border-[#eae1da] space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-[#1f1b17]">Background Aesthetic</h2>
                <p className="text-xs text-[#625d5b]">Select an atmospheric physical paper style</p>
              </div>
              <span className="text-xs text-[#625d5b] bg-[#f0e6e0] px-2 py-0.5 rounded font-medium">
                3 Themes
              </span>
            </div>

            <div className="grid grid-cols-1 gap-2.5">
              {themes.map((t) => {
                const isSelected = designState.theme === t.id;
                return (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => handleSelectTheme(t.id)}
                    className={`text-left p-3.5 rounded-lg transition-all flex items-center justify-between cursor-pointer ${
                      isSelected
                        ? 'bg-[#fcf2eb] ring-2 ring-[#3525cd] shadow-sm'
                        : 'bg-[#fcf2eb]/70 hover:bg-[#f6ece6] border border-[#eae1da]/50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className={`w-8 h-8 rounded-full flex items-center justify-center shadow-inner ${t.iconBg}`}>
                        <span className="material-symbols-outlined text-[18px]">
                          {t.icon}
                        </span>
                      </span>
                      <div>
                        <p className="text-sm font-bold text-[#1f1b17]">{t.name}</p>
                        <p className="text-xs text-[#625d5b]">{t.sub}</p>
                      </div>
                    </div>
                    {isSelected && (
                      <span
                        className="material-symbols-outlined text-[#3525cd] text-[20px]"
                        style={{ fontVariationSettings: "'FILL' 1" }}
                      >
                        check_circle
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section B & C: Sticker Library & Selected Stickers */}
          <div className="bg-white p-6 rounded-xl shadow-sm border border-[#eae1da] space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-[#1f1b17]">Celebratory Embellishments</h2>
                <p className="text-xs text-[#625d5b]">Curate tactile stickers for your digital pass</p>
              </div>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#e9e1dd] text-[#1e1b19] font-semibold">
                {designState.stickers.length} / 3 selected
              </span>
            </div>

            {/* Sticker Picker Buttons Grid */}
            <div className="grid grid-cols-2 gap-2">
              {Object.values(STICKER_CATALOG).map((stk) => {
                const isAttached = designState.stickers.some((s) => s.id === stk.id);
                return (
                  <button
                    key={stk.id}
                    type="button"
                    onClick={() => handleToggleSticker(stk.id)}
                    className={`flex items-center gap-2 p-2.5 rounded-lg text-left transition-all cursor-pointer ${
                      isAttached
                        ? 'bg-[#f6ece6] ring-1 ring-[#3525cd]/40 border-transparent shadow-sm'
                        : 'bg-[#fcf2eb] hover:bg-[#f6ece6] opacity-80 border border-[#eae1da]/50'
                    } ${stk.id === 'vip' ? 'col-span-2' : ''}`}
                  >
                    <span className="text-base">{stk.label.split(' ')[0]}</span>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-semibold text-[#1f1b17] truncate">
                        {stk.label.replace(/^[^\s]+\s*/, '')}
                      </p>
                      <span
                        className={`text-[11px] ${
                          isAttached
                            ? 'text-[#3525cd] font-semibold'
                            : 'text-[#625d5b]'
                        }`}
                      >
                        {isAttached ? 'Attached' : 'Add'}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Attached Stickers Strip with Explicit Removals */}
            <div className="pt-2 space-y-1.5">
              <label className="text-[11px] font-bold text-[#625d5b] uppercase tracking-wider block">
                Attached to Keepsake
              </label>
              <div className="flex flex-wrap gap-2 min-h-[38px] items-center p-2 rounded-lg bg-[#fcf2eb] border border-[#eae1da]/60">
                {designState.stickers.length === 0 ? (
                  <span className="text-xs text-[#625d5b] px-1">
                    No stickers attached yet. Tap any above to attach.
                  </span>
                ) : (
                  designState.stickers.map((stk) => (
                    <span
                      key={stk.id}
                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold shadow-xs ${stk.classes}`}
                    >
                      <span>{stk.label}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveSticker(stk.id)}
                        aria-label={`Remove ${stk.label}`}
                        className="w-4 h-4 rounded-full flex items-center justify-center hover:bg-black/10 transition-colors"
                      >
                        <span className="material-symbols-outlined text-[13px]">
                          close
                        </span>
                      </button>
                    </span>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Section D: Actions & Export Buttons */}
          <div className="bg-white p-6 rounded-xl shadow-sm border border-[#eae1da] space-y-3">
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                type="button"
                disabled={isSaving}
                onClick={handleSaveCard}
                className="flex-1 inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-[#3525cd] hover:bg-[#4f46e5] text-white text-sm font-semibold shadow-sm transition-all active:scale-[0.98] cursor-pointer disabled:opacity-80"
              >
                <span className="material-symbols-outlined text-[18px]">
                  verified
                </span>
                <span>{isSaving ? 'Saving card...' : 'Save Custom Card'}</span>
              </button>

              <button
                type="button"
                onClick={handleDownload}
                className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-[#e9e1dd] hover:bg-[#f0e6e0] text-[#1f1b17] text-sm font-semibold transition-colors cursor-pointer"
              >
                <span className="material-symbols-outlined text-[18px]">
                  download
                </span>
                <span>Download PNG</span>
              </button>
            </div>
            <div className="flex items-center gap-1.5 text-[#625d5b] text-xs pt-1">
              <span className="material-symbols-outlined text-[16px] text-[#005338]">
                offline_pin
              </span>
              <span>Renders at 300 DPI high-definition social format.</span>
            </div>
          </div>
        </section>

        {/* RIGHT: Live Visual Canvas (7 cols) */}
        <section aria-label="Live Keepsake Canvas" className="lg:col-span-7 flex flex-col items-center justify-center relative">
          {/* Overhead Mode Ribbon */}
          <div className="w-full max-w-[430px] flex items-center justify-between pb-2 px-1">
            <div className="flex items-center gap-1.5 text-[#625d5b]">
              <span className="material-symbols-outlined text-[16px]">
                aspect_ratio
              </span>
              <span className="text-xs uppercase tracking-wider font-semibold">
                Live Collectible Preview (4:5)
              </span>
            </div>
            <span className="text-xs font-mono text-[#625d5b]">Serial #BLR-2025-0819</span>
          </div>

          {/* Physical Card Container with Shadows and Bevels */}
          <div
            id={cardElementId}
            className={`relative w-full max-w-[430px] aspect-[4/5] rounded-3xl p-6 flex flex-col justify-between overflow-hidden shadow-2xl transition-all duration-500 border border-black/10 select-none ${
              designState.theme === 'indigo-midnight'
                ? 'bg-[#090D16] text-white'
                : designState.theme === 'civic-emerald'
                ? 'bg-[#E6F4EA] text-[#003824]'
                : 'bg-[#FAF7F2] text-[#1f1b17]'
            }`}
          >
            {/* Subtle Textured Paper Underlay */}
            <div
              className={`absolute inset-0 opacity-95 transition-all duration-500 pointer-events-none ${
                designState.theme === 'indigo-midnight'
                  ? 'bg-gradient-to-br from-[#1E1B4B] via-[#0F172A] to-[#090D16]'
                  : designState.theme === 'civic-emerald'
                  ? 'bg-gradient-to-br from-[#E6F4EA] via-[#CCE8D7] to-[#B3DBC4]'
                  : 'bg-gradient-to-br from-[#FAF7F2] via-[#F5EFEB] to-[#EAE1DA]'
              }`}
            />

            {/* Decorative Perforation Guides */}
            <div className="absolute -left-3 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-[#fff8f5] shadow-inner z-20"></div>
            <div className="absolute -right-3 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-[#fff8f5] shadow-inner z-20"></div>

            {/* Card Header & Dynamic Stickers */}
            <div className="relative z-10 flex items-start justify-between">
              <div className="space-y-1">
                <span className="px-2.5 py-0.5 rounded-full bg-[#e2dfff] text-[#0f0069] text-xs font-bold uppercase tracking-wider shadow-xs">
                  Civic Access Pass
                </span>
                <p className={`text-xs mt-1 font-medium ${
                  designState.theme === 'indigo-midnight' ? 'text-white/70' : 'text-[#625d5b]'
                }`}>
                  Bangalore District Arts Council
                </p>
              </div>

              {/* Dynamic Stickers Placement */}
              <div className="flex flex-col items-end gap-1.5 min-h-[70px]">
                {designState.stickers.map((stk) => (
                  <div
                    key={stk.id}
                    onClick={() => handleRemoveSticker(stk.id)}
                    title="Click to remove sticker"
                    className={`group/sticker cursor-pointer px-2.5 py-1 rounded-full text-xs font-bold shadow-sm transition-transform hover:scale-105 ${stk.classes} ${stk.rotate}`}
                  >
                    <span className="inline-flex items-center gap-1">
                      {stk.label}
                      <span className="opacity-0 group-hover/sticker:opacity-100 text-red-500 ml-0.5 font-bold">
                        ✕
                      </span>
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Hero Image & Event Details Spine */}
            <div className="relative z-10 my-auto py-2 space-y-3.5">
              {/* Event Hero Thumbnail Snapshot */}
              <div className="w-full h-36 rounded-2xl overflow-hidden relative shadow-md">
                <img
                  src={activeEvent.imageUrl}
                  alt={activeEvent.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                <div className="absolute bottom-3 left-3 right-3 text-white flex items-center justify-between text-xs">
                  <span className="font-semibold bg-white/20 backdrop-blur-md px-2 py-0.5 rounded text-white">
                    Live Performance
                  </span>
                  <span className="text-white/90 font-medium">
                    {activeEvent.venue || 'Hall A & Terrace Garden'}
                  </span>
                </div>
              </div>

              <div>
                <p className={`text-xs uppercase tracking-wider font-semibold ${
                  designState.theme === 'indigo-midnight' ? 'text-white/70' : 'text-[#625d5b]'
                }`}>
                  {activeEvent.neighborhood || 'Indiranagar Cultural Pavilion'}
                </p>
                <h3 className={`text-lg md:text-xl font-bold leading-tight mt-0.5 ${
                  designState.theme === 'indigo-midnight' ? 'text-white' : 'text-[#1f1b17]'
                }`}>
                  {activeEvent.title}
                </h3>
              </div>

              {/* Metadata Ribbon Table */}
              <div className="grid grid-cols-2 gap-2 pt-1">
                <div className="p-2.5 bg-white/40 backdrop-blur-sm rounded-lg border border-black/5">
                  <span className={`text-[11px] block ${
                    designState.theme === 'indigo-midnight' ? 'text-white/70' : 'text-[#625d5b]'
                  }`}>
                    Date & Schedule
                  </span>
                  <span className={`text-xs font-bold ${
                    designState.theme === 'indigo-midnight' ? 'text-white' : 'text-[#1f1b17]'
                  }`}>
                    {activeEvent.dateTime}
                  </span>
                </div>
                <div className="p-2.5 bg-white/40 backdrop-blur-sm rounded-lg border border-black/5">
                  <span className={`text-[11px] block ${
                    designState.theme === 'indigo-midnight' ? 'text-white/70' : 'text-[#625d5b]'
                  }`}>
                    Attendee Holder
                  </span>
                  <span className={`text-xs font-bold truncate block ${
                    designState.theme === 'indigo-midnight' ? 'text-white' : 'text-[#1f1b17]'
                  }`}>
                    {designState.attendeeName || 'Arun K. Ramaswamy'}
                  </span>
                </div>
              </div>
            </div>

            {/* Card Base: Tear-off Stub & Authentic QR Graphic */}
            <div className="relative z-10 pt-3 flex items-center justify-between border-t border-black/10">
              <div className="space-y-0.5">
                <span className={`text-[11px] block ${
                  designState.theme === 'indigo-midnight' ? 'text-white/70' : 'text-[#625d5b]'
                }`}>
                  Digital Gate Validation
                </span>
                <p className="text-xs font-mono font-semibold tracking-wider">
                  #AUTH-9821-C7
                </p>
                <div className="flex items-center gap-1 text-[#005338] text-xs font-bold mt-0.5">
                  <span className="material-symbols-outlined text-[14px]">
                    lock
                  </span>
                  <span>Verified Collector Proof</span>
                </div>
              </div>

              {/* Authentic Procedural SVG QR Code */}
              <div className="p-2 rounded-xl bg-white shadow-sm flex items-center justify-center">
                <svg
                  className="text-black"
                  fill="currentColor"
                  height="64"
                  viewBox="0 0 100 100"
                  width="64"
                >
                  <rect
                    fill="none"
                    height="28"
                    rx="4"
                    stroke="currentColor"
                    strokeWidth="7"
                    width="28"
                    x="10"
                    y="10"
                  />
                  <rect height="14" rx="2" width="14" x="17" y="17" />
                  <rect
                    fill="none"
                    height="28"
                    rx="4"
                    stroke="currentColor"
                    strokeWidth="7"
                    width="28"
                    x="62"
                    y="10"
                  />
                  <rect height="14" rx="2" width="14" x="69" y="17" />
                  <rect
                    fill="none"
                    height="28"
                    rx="4"
                    stroke="currentColor"
                    strokeWidth="7"
                    width="28"
                    x="10"
                    y="62"
                  />
                  <rect height="14" rx="2" width="14" x="17" y="69" />
                  <rect height="8" rx="1.5" width="8" x="46" y="12" />
                  <rect height="18" rx="1.5" width="8" x="46" y="26" />
                  <rect height="8" rx="1.5" width="16" x="12" y="46" />
                  <rect height="8" rx="1.5" width="8" x="34" y="46" />
                  <rect height="8" rx="1.5" width="14" x="48" y="52" />
                  <rect height="16" rx="1.5" width="8" x="68" y="46" />
                  <rect height="8" rx="1.5" width="8" x="82" y="50" />
                  <rect height="14" rx="1.5" width="8" x="48" y="68" />
                  <rect height="8" rx="1.5" width="16" x="64" y="70" />
                  <rect height="10" rx="1.5" width="10" x="80" y="80" />
                  <rect height="6" rx="1.5" width="8" x="64" y="84" />
                </svg>
              </div>
            </div>
          </div>

          {/* Quick Switch Indicator Micro-Bar */}
          <div className="mt-4 flex items-center gap-6 text-[#625d5b] text-xs">
            <span className="flex items-center gap-1.5 font-medium">
              <span className="w-1.5 h-1.5 rounded-full bg-[#3525cd]"></span>
              Auto-Sync Active
            </span>
            <span className="flex items-center gap-1.5 font-medium">
              <span className="w-1.5 h-1.5 rounded-full bg-[#c7c4d8]"></span>
              Apple Wallet Ready
            </span>
          </div>
        </section>
      </div>
    </div>
  );
};
