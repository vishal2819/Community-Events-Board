import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="w-full bg-[#fcf2eb] border-t border-[#eae1da]/60 mt-12">
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-8 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex flex-wrap items-center justify-center md:justify-start gap-6 text-xs text-[#464555]">
          <a
            href="#guidelines"
            onClick={(e) => e.preventDefault()}
            className="hover:text-[#1f1b17] transition-colors"
          >
            Community Guidelines
          </a>
          <a
            href="#accessibility"
            onClick={(e) => e.preventDefault()}
            className="hover:text-[#1f1b17] transition-colors"
          >
            Accessibility Statement
          </a>
          <a
            href="#privacy"
            onClick={(e) => e.preventDefault()}
            className="hover:text-[#1f1b17] transition-colors"
          >
            Privacy Policy
          </a>
        </div>
        <div className="text-xs text-[#464555] text-center md:text-right">
          © 2025 Community Events Board. Civic Cultural Collective.
        </div>
      </div>
    </footer>
  );
};
