import React, { useState } from 'react';
import { AppScreen } from '../types';

interface AuthViewProps {
  onNavigate: (screen: AppScreen) => void;
  onLoginSuccess: (email: string) => void;
  onShowToast: (title: string, desc: string) => void;
}

export const AuthView: React.FC<AuthViewProps> = ({
  onNavigate,
  onLoginSuccess,
  onShowToast
}) => {
  const [authTab, setAuthTab] = useState<'signin' | 'signup'>('signin');
  const [showErrorBanner, setShowErrorBanner] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form Fields
  const [signInEmail, setSignInEmail] = useState('arun@civic.community');
  const [signInPassword, setSignInPassword] = useState('Koramangala#2025');
  const [showSignInPassword, setShowSignInPassword] = useState(false);
  const [rememberDevice, setRememberDevice] = useState(true);

  // Sign up fields
  const [signUpName, setSignUpName] = useState('Ananya Rao');
  const [signUpEmail, setSignUpEmail] = useState('ananya.rao@civic.community');
  const [signUpPassword, setSignUpPassword] = useState('');
  const [showSignUpPassword, setShowSignUpPassword] = useState(false);
  const [signUpConfirmPassword, setSignUpConfirmPassword] = useState('');
  const [termsAccepted, setTermsAccepted] = useState(false);

  // Password Strength Calculation
  const passwordStrength = (() => {
    const len = signUpPassword.length;
    if (len === 0) return { label: 'None', level: 0, color: 'bg-[#eae1da]' };
    if (len < 6) return { label: 'Weak', level: 1, color: 'bg-[#ba1a1a]' };
    if (len < 10) return { label: 'Moderate', level: 2, color: 'bg-[#625d5b]' };
    return { label: 'Strong', level: 4, color: 'bg-[#005338]' };
  })();

  const handleSignInSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (isSubmitting) return;

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setShowErrorBanner(false);
      onLoginSuccess(signInEmail);
      onShowToast(
        'Authentication Verified',
        `Welcome back, ${signInEmail.split('@')[0]}! Redirecting to events board.`
      );
      onNavigate('discover-events');
    }, 1200);
  };

  const handleSignUpSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (isSubmitting) return;

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      onLoginSuccess(signUpEmail);
      onShowToast(
        'Civic Account Provisioned',
        `Account for ${signUpName} created. Welcome to Bengaluru Civic Collective.`
      );
      onNavigate('favourite-categories');
    }, 1200);
  };

  return (
    <div className="relative w-full max-w-7xl mx-auto px-4 md:px-8 py-6 md:py-10 overflow-hidden">
      {/* Background Ambient Glow */}
      <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-[600px] h-[340px] bg-gradient-to-br from-[#c3c0ff]/30 via-[#3525cd]/5 to-transparent rounded-full blur-3xl pointer-events-none -z-10"></div>
      <div className="absolute top-1/3 -right-20 w-80 h-80 bg-[#68dba9]/20 rounded-full blur-3xl pointer-events-none -z-10"></div>

      {/* Navigation Breadcrumb & Back Action */}
      <div className="flex items-center justify-between gap-4 mb-6 md:mb-8">
        <button
          type="button"
          onClick={() => onNavigate('discover-events')}
          className="inline-flex items-center gap-1.5 text-[#464555] hover:text-[#1f1b17] text-sm font-semibold transition-colors group cursor-pointer"
        >
          <span className="material-symbols-outlined text-[18px] transition-transform group-hover:-translate-x-1">
            arrow_back
          </span>
          <span>Back to Events Discovery</span>
        </button>
        <div className="flex items-center gap-1.5 text-xs text-[#464555]">
          <span className="w-2 h-2 rounded-full bg-[#005338] animate-pulse"></span>
          <span className="hidden sm:inline">Bengaluru Municipal Federation • Secure Auth node</span>
        </div>
      </div>

      {/* Main Grid: Editorial Canvas with Interactive Dual Auth Surface */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Civic Editorial Manifest (5 Cols) */}
        <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#e9e1dd] text-[#1e1b19] text-xs font-bold uppercase tracking-wider">
              <span className="material-symbols-outlined text-[14px] text-[#3525cd]">
                verified_user
              </span>
              <span>Civic Credential Gateway</span>
            </div>
            <h1 className="text-3xl md:text-4xl font-bold text-[#1f1b17] tracking-tight">
              Curate, attend, and champion neighborhood culture.
            </h1>
            <p className="text-sm md:text-base text-[#464555] leading-relaxed">
              Access citywide collective programs, reserve workshop seating, coordinate grassroots initiatives, and participate in verified civic discourse.
            </p>
          </div>

          {/* Curated Metric Mini-Bento Card */}
          <div className="bg-[#fcf2eb] rounded-xl p-5 shadow-sm border border-[#eae1da] space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#464555] uppercase tracking-wider">
                Active Municipal Pulse
              </span>
              <span className="px-2 py-0.5 rounded bg-[#85f8c4] text-[#002114] text-[11px] font-bold">
                Live
              </span>
            </div>

            {/* Inline Activity Line */}
            <div className="space-y-1">
              <div className="flex items-baseline justify-between">
                <span className="text-2xl font-bold text-[#1f1b17]">1,420+</span>
                <span className="text-xs text-[#005338] font-bold flex items-center gap-0.5">
                  <span className="material-symbols-outlined text-[14px]">trending_up</span>{' '}
                  +18.4% this week
                </span>
              </div>
              <p className="text-xs text-[#464555]">
                Validated community members engaged across 48 local ward boards.
              </p>
              <div className="h-14 w-full pt-2">
                <svg
                  className="w-full h-full overflow-visible text-[#3525cd]"
                  fill="none"
                  viewBox="0 0 300 50"
                >
                  <path
                    d="M0,40 Q30,35 60,38 T120,24 T180,30 T240,12 T300,5"
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeWidth="2.5"
                  />
                  <path
                    d="M0,40 Q30,35 60,38 T120,24 T180,30 T240,12 T300,5 L300,50 L0,50 Z"
                    fill="currentColor"
                    opacity="0.08"
                  />
                </svg>
              </div>
            </div>

            <div className="pt-2 flex items-center gap-2 border-t border-[#eae1da]/60">
              <div className="flex -space-x-2 overflow-hidden">
                <div className="w-7 h-7 rounded-full bg-[#e2dfff] flex items-center justify-center text-xs text-[#0f0069] font-bold shadow-xs">
                  AK
                </div>
                <div className="w-7 h-7 rounded-full bg-[#e9e1dd] flex items-center justify-center text-xs text-[#1e1b19] font-bold shadow-xs">
                  SR
                </div>
                <div className="w-7 h-7 rounded-full bg-[#85f8c4] flex items-center justify-center text-xs text-[#002114] font-bold shadow-xs">
                  MN
                </div>
                <div className="w-7 h-7 rounded-full bg-[#f0e6e0] flex items-center justify-center text-[10px] text-[#464555] font-semibold shadow-xs">
                  +9
                </div>
              </div>
              <span className="text-xs text-[#464555]">
                Joined from Indiranagar, Malleshwaram & Koramangala
              </span>
            </div>
          </div>

          {/* Editorial Visual Spotlight Banner */}
          <div className="relative rounded-xl overflow-hidden shadow-sm bg-[#f6ece6] border border-[#eae1da]">
            <div className="relative h-44 w-full">
              <img
                className="w-full h-full object-cover"
                alt="Civic Assembly Series"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuB_TZPyFgWq_3Z2cKQs2bEm7fYiS-iz4m63dRsTkKkyUwvRJ6xf4UJCtXwkMu3iOsBZgh2daVE5EuKgL__XcueT9-nlvDw5H_1GYdFq6io9O4t05lbc229ZShzt2jqspHv_-XyjOY6UoFM0GtB6Y7KA6FwNydtLu32-n9j-GsXQfe7LerBGLzzYUqeC6B7yNReGuQcqZCjxNu-Ffs-g1osJKR65D9uIOBrKVlFTiW8Wgb2dXqsV4eNW"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent"></div>
              <div className="absolute bottom-3 left-4 right-4 text-white">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#85f8c4]">
                  Civic Assembly Series
                </span>
                <p className="text-xs sm:text-sm font-semibold truncate text-white">
                  Annual Heritage Walk & Lake Restoration Forum
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Interactive Tabbed Auth Deck (7 Cols) */}
        <div className="lg:col-span-7">
          <div className="bg-white rounded-xl shadow-md p-6 sm:p-8 border border-[#eae1da]">
            {/* Segmented Tab Header */}
            <div className="bg-[#f6ece6] rounded-lg p-1.5 flex items-center justify-between mb-6 shadow-inner border border-[#eae1da]">
              <button
                type="button"
                onClick={() => setAuthTab('signin')}
                className={`flex-1 py-2 px-4 rounded-md text-xs font-semibold transition-all text-center flex items-center justify-center gap-1.5 cursor-pointer ${
                  authTab === 'signin'
                    ? 'bg-white text-[#1f1b17] shadow-sm'
                    : 'text-[#464555] hover:text-[#1f1b17]'
                }`}
              >
                <span className="material-symbols-outlined text-[18px]">
                  login
                </span>
                <span>Sign In</span>
              </button>

              <button
                type="button"
                onClick={() => setAuthTab('signup')}
                className={`flex-1 py-2 px-4 rounded-md text-xs font-semibold transition-all text-center flex items-center justify-center gap-1.5 cursor-pointer ${
                  authTab === 'signup'
                    ? 'bg-white text-[#1f1b17] shadow-sm'
                    : 'text-[#464555] hover:text-[#1f1b17]'
                }`}
              >
                <span className="material-symbols-outlined text-[18px]">
                  person_add
                </span>
                <span>Create Account</span>
              </button>
            </div>

            {/* SIGN IN FORM VIEW */}
            {authTab === 'signin' ? (
              <div className="space-y-4">
                <div>
                  <h2 className="text-xl font-bold text-[#1f1b17]">
                    Welcome back to the Board
                  </h2>
                  <p className="text-xs text-[#464555] mt-0.5">
                    Enter your municipal civic login credentials to continue.
                  </p>
                </div>

                {/* Inline Error Callout */}
                {showErrorBanner && (
                  <div className="flex items-start gap-2.5 p-3 rounded-lg bg-[#ffdad6] text-[#93000a] text-xs font-medium border border-[#ba1a1a]/20">
                    <span className="material-symbols-outlined text-[#ba1a1a] text-[18px] shrink-0 mt-0.5">
                      error
                    </span>
                    <div className="flex-1">
                      <strong className="font-semibold">Authentication failure:</strong>
                      <span className="ml-1">
                        Invalid credentials. Please verify your registered civic email and password combination.
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowErrorBanner(false)}
                      className="text-[#93000a]/70 hover:text-[#93000a]"
                    >
                      <span className="material-symbols-outlined text-[16px]">close</span>
                    </button>
                  </div>
                )}

                <form onSubmit={handleSignInSubmit} className="space-y-4">
                  {/* Email Input */}
                  <div className="space-y-1">
                    <label
                      htmlFor="signin-email"
                      className="block text-xs font-semibold text-[#1f1b17]"
                    >
                      Email address <span className="text-red-500">*</span>
                    </label>
                    <div className="relative rounded-lg shadow-xs">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#777587]">
                        <span className="material-symbols-outlined text-[18px]">
                          mail
                        </span>
                      </div>
                      <input
                        id="signin-email"
                        type="email"
                        required
                        value={signInEmail}
                        onChange={(e) => setSignInEmail(e.target.value)}
                        placeholder="arun@civic.community"
                        className="block w-full pl-10 pr-3 py-2 text-sm rounded-lg bg-[#fcf2eb] text-[#1f1b17] border border-[#eae1da] focus:outline-none focus:bg-white focus:ring-2 focus:ring-[#3525cd]/20"
                      />
                    </div>
                    <p className="text-[11px] text-[#464555]">
                      Use the email associated with your municipal RSVP identity.
                    </p>
                  </div>

                  {/* Password Input with Toggle */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <label
                        htmlFor="signin-password"
                        className="block text-xs font-semibold text-[#1f1b17]"
                      >
                        Password <span className="text-red-500">*</span>
                      </label>
                    </div>
                    <div className="relative rounded-lg shadow-xs">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#777587]">
                        <span className="material-symbols-outlined text-[18px]">
                          lock
                        </span>
                      </div>
                      <input
                        id="signin-password"
                        type={showSignInPassword ? 'text' : 'password'}
                        required
                        value={signInPassword}
                        onChange={(e) => setSignInPassword(e.target.value)}
                        placeholder="••••••••••••"
                        className="block w-full pl-10 pr-10 py-2 text-sm rounded-lg bg-[#fcf2eb] text-[#1f1b17] border border-[#eae1da] focus:outline-none focus:bg-white focus:ring-2 focus:ring-[#3525cd]/20"
                      />
                      <button
                        type="button"
                        onClick={() => setShowSignInPassword(!showSignInPassword)}
                        className="absolute inset-y-0 right-0 pr-3 flex items-center text-[#777587] hover:text-[#1f1b17]"
                      >
                        <span className="material-symbols-outlined text-[18px]">
                          {showSignInPassword ? 'visibility_off' : 'visibility'}
                        </span>
                      </button>
                    </div>
                    <div className="flex items-center gap-1.5 text-[#464555] text-[11px]">
                      <span className="material-symbols-outlined text-[14px] text-[#005338]">
                        check_circle
                      </span>
                      <span>Must be at least 8 characters with one number</span>
                    </div>
                  </div>

                  {/* Remember Device Checkbox */}
                  <div className="flex items-center justify-between pt-1 text-xs">
                    <label className="flex items-center gap-2 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={rememberDevice}
                        onChange={(e) => setRememberDevice(e.target.checked)}
                        className="w-4 h-4 rounded text-[#3525cd] accent-[#3525cd]"
                      />
                      <span className="text-[#1f1b17] font-medium">
                        Remember this device for 30 days
                      </span>
                    </label>
                    <span className="text-[#464555]">Device token cached</span>
                  </div>

                  {/* Primary Submit Action */}
                  <div className="pt-2 space-y-2">
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-2.5 px-4 rounded-lg bg-[#3525cd] hover:bg-[#4f46e5] text-white text-xs font-semibold transition-all shadow-sm flex items-center justify-center gap-2 active:scale-[0.99] cursor-pointer disabled:opacity-80"
                    >
                      {isSubmitting ? (
                        <>
                          <span className="material-symbols-outlined text-[18px] animate-spin">
                            progress_activity
                          </span>
                          <span>Verifying municipal credentials...</span>
                        </>
                      ) : (
                        <span>Sign In to Community Events</span>
                      )}
                    </button>
                    <div className="flex items-center justify-center gap-1 text-xs">
                      <span className="text-[#464555]">
                        Need to verify identity details?
                      </span>
                      <button
                        type="button"
                        onClick={() => setAuthTab('signup')}
                        className="text-[#3525cd] hover:underline font-semibold cursor-pointer"
                      >
                        Request invitation / Signup
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            ) : (
              /* CREATE ACCOUNT VIEW */
              <div className="space-y-4">
                <div>
                  <h2 className="text-xl font-bold text-[#1f1b17]">
                    Create your Civic Profile
                  </h2>
                  <p className="text-xs text-[#464555] mt-0.5">
                    Register as an attendee or event curator in your local ward.
                  </p>
                </div>

                <div className="p-3 rounded-lg bg-[#f6ece6] flex items-center gap-2 text-[#464555] text-xs">
                  <span className="material-symbols-outlined text-[16px] text-[#005338]">
                    info
                  </span>
                  <span>
                    Resident verification provides priority RSVP to localized municipal venues.
                  </span>
                </div>

                <form onSubmit={handleSignUpSubmit} className="space-y-3.5">
                  {/* Full Name */}
                  <div className="space-y-1">
                    <label
                      htmlFor="signup-name"
                      className="block text-xs font-semibold text-[#1f1b17]"
                    >
                      Full Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      id="signup-name"
                      type="text"
                      required
                      value={signUpName}
                      onChange={(e) => setSignUpName(e.target.value)}
                      placeholder="Ananya Rao"
                      className="block w-full px-3 py-2 text-sm rounded-lg bg-[#fcf2eb] text-[#1f1b17] border border-[#eae1da] focus:outline-none focus:bg-white"
                    />
                  </div>

                  {/* Email */}
                  <div className="space-y-1">
                    <label
                      htmlFor="signup-email"
                      className="block text-xs font-semibold text-[#1f1b17]"
                    >
                      Email address <span className="text-red-500">*</span>
                    </label>
                    <input
                      id="signup-email"
                      type="email"
                      required
                      value={signUpEmail}
                      onChange={(e) => setSignUpEmail(e.target.value)}
                      placeholder="ananya.rao@civic.community"
                      className="block w-full px-3 py-2 text-sm rounded-lg bg-[#fcf2eb] text-[#1f1b17] border border-[#eae1da] focus:outline-none focus:bg-white"
                    />
                  </div>

                  {/* Password with Strength Meter */}
                  <div className="space-y-1">
                    <label
                      htmlFor="signup-password"
                      className="block text-xs font-semibold text-[#1f1b17]"
                    >
                      Password <span className="text-red-500">*</span>
                    </label>
                    <div className="relative rounded-lg">
                      <input
                        id="signup-password"
                        type={showSignUpPassword ? 'text' : 'password'}
                        required
                        value={signUpPassword}
                        onChange={(e) => setSignUpPassword(e.target.value)}
                        placeholder="Create strong passphrase"
                        className="block w-full pl-3 pr-10 py-2 text-sm rounded-lg bg-[#fcf2eb] text-[#1f1b17] border border-[#eae1da] focus:outline-none focus:bg-white"
                      />
                      <button
                        type="button"
                        onClick={() => setShowSignUpPassword(!showSignUpPassword)}
                        className="absolute inset-y-0 right-0 pr-3 flex items-center text-[#777587]"
                      >
                        <span className="material-symbols-outlined text-[18px]">
                          {showSignUpPassword ? 'visibility_off' : 'visibility'}
                        </span>
                      </button>
                    </div>

                    {/* Password Strength Meter Bar */}
                    <div className="pt-1 space-y-1">
                      <div className="flex items-center justify-between text-[11px] text-[#464555]">
                        <span>Password strength:</span>
                        <span className="font-semibold">{passwordStrength.label}</span>
                      </div>
                      <div className="w-full h-1.5 bg-[#f6ece6] rounded-full overflow-hidden flex gap-1">
                        {[1, 2, 3, 4].map((barIndex) => (
                          <div
                            key={barIndex}
                            className={`h-full flex-1 rounded-full transition-colors ${
                              passwordStrength.level >= barIndex
                                ? passwordStrength.color
                                : 'bg-[#eae1da]'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Confirm Password */}
                  <div className="space-y-1">
                    <label
                      htmlFor="signup-confirm"
                      className="block text-xs font-semibold text-[#1f1b17]"
                    >
                      Confirm Password <span className="text-red-500">*</span>
                    </label>
                    <input
                      id="signup-confirm"
                      type="password"
                      required
                      value={signUpConfirmPassword}
                      onChange={(e) => setSignUpConfirmPassword(e.target.value)}
                      placeholder="Re-enter your password"
                      className="block w-full px-3 py-2 text-sm rounded-lg bg-[#fcf2eb] text-[#1f1b17] border border-[#eae1da] focus:outline-none"
                    />
                  </div>

                  {/* Terms */}
                  <label className="flex items-start gap-2 pt-1 text-xs text-[#464555] cursor-pointer">
                    <input
                      type="checkbox"
                      required
                      checked={termsAccepted}
                      onChange={(e) => setTermsAccepted(e.target.checked)}
                      className="w-4 h-4 mt-0.5 rounded text-[#3525cd] accent-[#3525cd]"
                    />
                    <span>
                      I agree to the Community Code of Conduct and Municipal Civic Privacy Charter.
                    </span>
                  </label>

                  {/* Submit */}
                  <div className="pt-2 space-y-2">
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-2.5 px-4 rounded-lg bg-[#3525cd] hover:bg-[#4f46e5] text-white text-xs font-semibold shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-80"
                    >
                      {isSubmitting ? (
                        <>
                          <span className="material-symbols-outlined text-[18px] animate-spin">
                            progress_activity
                          </span>
                          <span>Provisioning Civic ID...</span>
                        </>
                      ) : (
                        <span>Create Civic Account</span>
                      )}
                    </button>
                    <div className="flex items-center justify-center gap-1 text-xs">
                      <span className="text-[#464555]">
                        Already have registered credentials?
                      </span>
                      <button
                        type="button"
                        onClick={() => setAuthTab('signin')}
                        className="text-[#3525cd] hover:underline font-semibold cursor-pointer"
                      >
                        Sign in here
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            )}

            {/* Section 4.B Trust & Compliance Banner */}
            <div className="mt-6 pt-4 bg-[#fcf2eb] rounded-lg p-3 flex items-center gap-2.5 border border-[#eae1da]">
              <span className="material-symbols-outlined text-[#3525cd] text-[20px] shrink-0">
                shield_lock
              </span>
              <p className="text-[11px] text-[#464555] leading-tight">
                Secured with encrypted HTTP-only session tokens. FyerX technical assessment auth boundary. Social logins and open password-reset workflows are strictly excluded per Section 4.B specification.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Assessment Sandbox State Controls */}
      <div className="mt-8 p-4 rounded-xl bg-[#f0e6e0] flex flex-col md:flex-row items-center justify-between gap-4 border border-[#eae1da]">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-[#e2dfff] flex items-center justify-center text-[#3525cd]">
            <span className="material-symbols-outlined text-[18px]">tune</span>
          </div>
          <div>
            <span className="text-xs font-bold text-[#1f1b17]">
              Assessment Sandbox State Controls
            </span>
            <p className="text-[11px] text-[#464555]">
              Toggle inline error state or trigger asynchronous loading demonstration
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => setShowErrorBanner(!showErrorBanner)}
            className="px-3.5 py-1.5 rounded-lg bg-white text-[#1f1b17] text-xs font-semibold hover:bg-[#f6ece6] transition-colors shadow-xs border border-[#eae1da] cursor-pointer"
          >
            {showErrorBanner ? 'Hide Error Callout' : 'Toggle Error Callout'}
          </button>
          <button
            type="button"
            onClick={() => handleSignInSubmit()}
            className="px-3.5 py-1.5 rounded-lg bg-white text-[#1f1b17] text-xs font-semibold hover:bg-[#f6ece6] transition-colors shadow-xs border border-[#eae1da] cursor-pointer"
          >
            Simulate Async Submit
          </button>
        </div>
      </div>
    </div>
  );
};
