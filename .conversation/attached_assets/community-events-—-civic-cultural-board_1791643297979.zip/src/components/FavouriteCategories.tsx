import React, { useState } from 'react';
import { CategoryPreference, AppScreen } from '../types';

interface FavouriteCategoriesProps {
  categories: CategoryPreference[];
  onToggleCategory: (id: string) => void;
  onSavePreferences: () => void;
  onNavigate: (screen: AppScreen) => void;
  onShowToast: (title: string, desc: string) => void;
}

export const FavouriteCategories: React.FC<FavouriteCategoriesProps> = ({
  categories,
  onToggleCategory,
  onSavePreferences,
  onNavigate,
  onShowToast
}) => {
  const [isSaving, setIsSaving] = useState(false);
  const [isPersisted, setIsPersisted] = useState(false);

  const selectedCount = categories.filter((c) => c.selected).length;

  const handleSave = () => {
    if (isSaving) return;
    setIsSaving(true);

    setTimeout(() => {
      setIsSaving(false);
      setIsPersisted(true);
      onSavePreferences();
      onShowToast(
        'Preferences synchronized',
        `Your tailored feed reflects your ${selectedCount} chosen topics.`
      );
    }, 900);
  };

  return (
    <div className="flex flex-col w-full">
      <div className="max-w-6xl mx-auto w-full px-4 md:px-8 py-8 md:py-12 flex flex-col gap-8 md:gap-10">
        {/* Step Badge & Centered Editorial Header */}
        <div className="flex flex-col items-center text-center max-w-2xl mx-auto gap-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#e9e1dd] text-[#1e1b19] text-xs font-semibold">
            <span className="w-1.5 h-1.5 rounded-full bg-[#3525cd] animate-pulse"></span>
            <span>Step 1 of 2 • Personalization</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-[#1f1b17] tracking-tight">
            Tailor your community board
          </h1>
          <p className="text-base text-[#464555] max-w-xl">
            Choose the topics you love most. We will prioritize these in your personalized feed and notify you when new events get announced in your city.
          </p>
          {/* Progress Meter Indicator */}
          <div className="w-48 h-1.5 bg-[#f0e6e0] rounded-full overflow-hidden mt-1">
            <div className="h-full bg-[#3525cd] rounded-full transition-all duration-500 w-1/2" />
          </div>
        </div>

        {/* Category Cards Interactive Mosaic Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 w-full">
          {categories.map((cat) => {
            const isChecked = cat.selected;
            return (
              <div
                key={cat.id}
                role="checkbox"
                tabIndex={0}
                aria-checked={isChecked}
                onClick={() => {
                  if (isPersisted) setIsPersisted(false);
                  onToggleCategory(cat.id);
                }}
                onKeyDown={(e) => {
                  if (e.key === ' ' || e.key === 'Enter') {
                    e.preventDefault();
                    if (isPersisted) setIsPersisted(false);
                    onToggleCategory(cat.id);
                  }
                }}
                className={`group relative bg-white rounded-xl p-6 shadow-sm hover:shadow-md cursor-pointer transition-all duration-200 select-none flex flex-col justify-between h-[230px] border ${
                  isChecked
                    ? 'border-[#3525cd]/40 ring-1 ring-[#3525cd]/20'
                    : 'border-[#eae1da]'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center transition-transform duration-200 group-hover:scale-105 ${
                      isChecked
                        ? 'bg-[#f6ece6] text-[#3525cd]'
                        : 'bg-[#f6ece6] text-[#464555]'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[26px]">
                      {cat.icon}
                    </span>
                  </div>

                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center transition-colors ${
                      isChecked
                        ? 'bg-[#3525cd] text-white'
                        : 'bg-[#f6ece6] text-[#464555] group-hover:bg-[#e9e1dd]'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[18px]">
                      {isChecked ? 'check' : 'add'}
                    </span>
                  </div>
                </div>

                <div className="flex flex-col gap-1.5 mt-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-bold text-[#1f1b17]">{cat.name}</h3>
                    <span className="px-2 py-0.5 rounded-full bg-[#f6ece6] text-[#464555] text-xs font-semibold">
                      {cat.upcomingCount} upcoming
                    </span>
                  </div>
                  <p className="text-xs text-[#464555] line-clamp-2 leading-relaxed">
                    {cat.description}
                  </p>
                </div>

                {/* Accent glow bar for selected state */}
                <div
                  className={`absolute bottom-0 left-0 right-0 h-1 bg-[#3525cd] rounded-b-xl transition-opacity duration-200 ${
                    isChecked ? 'opacity-100' : 'opacity-0'
                  }`}
                />
              </div>
            );
          })}

          {/* Informational Prompt Tile (Bento Balance) */}
          <div className="relative bg-[#f6ece6] rounded-xl p-6 shadow-sm flex flex-col justify-between h-[230px] border border-[#eae1da]">
            <div className="flex items-center gap-2 text-[#464555]">
              <span className="material-symbols-outlined text-[22px] text-[#005338]">
                tune
              </span>
              <span className="text-xs font-bold uppercase tracking-wider text-[#005338]">
                Live Algorithmic Sync
              </span>
            </div>
            <p className="text-xs text-[#464555] leading-relaxed">
              You can refine or mute topics anytime directly inside your personal account preferences or from individual event detail views.
            </p>
            <div className="flex items-center gap-1.5 text-[#464555] text-xs font-medium">
              <span className="material-symbols-outlined text-[16px]">
                lock_reset
              </span>
              <span>Zero third-party telemetry tracking</span>
            </div>
          </div>
        </div>

        {/* Editorial Confirmation Panel */}
        <div className="w-full bg-white rounded-xl shadow-md p-6 flex flex-col md:flex-row items-center justify-between gap-6 border border-[#eae1da]">
          {/* Selection Tally with Micro-Indicator */}
          <div className="flex items-center gap-4 w-full md:w-auto">
            <div className="w-10 h-10 rounded-full bg-[#f6ece6] flex items-center justify-center text-[#3525cd] shrink-0">
              <span className="material-symbols-outlined text-[20px]">
                filter_vintage
              </span>
            </div>
            <div className="flex flex-col">
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold text-[#1f1b17]">
                  {selectedCount} {selectedCount === 1 ? 'category' : 'categories'} selected
                </span>
                <span className="w-2 h-2 rounded-full bg-[#005338]"></span>
              </div>
              <span
                className={`text-xs ${
                  isPersisted ? 'text-[#005338] font-semibold' : 'text-[#464555]'
                }`}
              >
                {isPersisted
                  ? 'Saved to civic cloud'
                  : 'Pending user confirmation'}
              </span>
            </div>
          </div>

          {/* Action Group */}
          <div className="flex items-center gap-4 w-full md:w-auto justify-end">
            <button
              type="button"
              onClick={() => onNavigate('my-feed')}
              className="px-4 py-2.5 rounded-lg bg-[#fff8f5] hover:bg-[#f6ece6] text-[#464555] hover:text-[#1f1b17] text-sm font-medium transition-colors"
            >
              Skip for now
            </button>

            <button
              type="button"
              disabled={isSaving}
              onClick={handleSave}
              className="relative overflow-hidden px-6 py-2.5 rounded-lg bg-[#3525cd] hover:bg-[#4f46e5] text-white text-sm font-semibold shadow-sm transition-all flex items-center justify-center gap-2 min-w-[170px] disabled:opacity-80 active:scale-95"
            >
              {isSaving ? (
                <span className="flex items-center gap-2">
                  <svg
                    className="animate-spin h-4 w-4 text-white"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    />
                    <path
                      className="opacity-75"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      fill="currentColor"
                    />
                  </svg>
                  <span>Saving...</span>
                </span>
              ) : isPersisted ? (
                <span className="flex items-center gap-1.5">
                  <span>Saved</span>
                  <span className="material-symbols-outlined text-[18px]">
                    done_all
                  </span>
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  <span>Save Preferences</span>
                  <span className="material-symbols-outlined text-[18px]">
                    arrow_forward
                  </span>
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Confirmed Feedback Banner (Revealed post-save) */}
        {isPersisted && (
          <div className="w-full bg-[#fcf2eb] rounded-xl p-6 shadow-sm border border-[#85f8c4]/60 animate-in fade-in duration-300">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-[#85f8c4] text-[#002114] flex items-center justify-center shrink-0 shadow-sm">
                  <span className="material-symbols-outlined text-[24px]">
                    verified
                  </span>
                </div>
                <div className="flex flex-col">
                  <h4 className="text-base md:text-lg font-bold text-[#1f1b17]">
                    Preferences successfully saved!
                  </h4>
                  <p className="text-xs md:text-sm text-[#464555]">
                    The municipal event board has been recalibrated to highlight your chosen cultural interests.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('my-feed')}
                className="px-5 py-2.5 rounded-lg bg-[#3525cd] text-white text-sm font-semibold shadow-sm hover:bg-[#4f46e5] transition-all flex items-center gap-2 shrink-0"
              >
                <span>Go to My Feed</span>
                <span className="material-symbols-outlined text-[18px]">
                  arrow_right_alt
                </span>
              </button>
            </div>
          </div>
        )}

        {/* Editorial Community Footer Note */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 py-2 text-xs text-[#464555]">
          <div className="flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[16px] text-[#005338]">
              check
            </span>
            <span>Curated by local civic boards in Bengaluru, IN</span>
          </div>
          <div>Need custom topics? Suggest via Civic Cultural Collective portal.</div>
        </div>
      </div>
    </div>
  );
};
