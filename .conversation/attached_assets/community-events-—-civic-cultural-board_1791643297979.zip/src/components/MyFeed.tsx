import React, { useState, useMemo } from 'react';
import { EventItem, CategoryPreference, AppScreen } from '../types';

interface MyFeedProps {
  events: EventItem[];
  categories: CategoryPreference[];
  onNavigate: (screen: AppScreen) => void;
  onDesignPass: (eventId: string) => void;
  onRsvpClick: (event: EventItem) => void;
  onShowToast: (title: string, desc: string) => void;
  reminders: Record<string, boolean>;
  onToggleReminder: (eventId: string, title: string) => void;
}

export const MyFeed: React.FC<MyFeedProps> = ({
  events,
  categories,
  onNavigate,
  onDesignPass,
  onRsvpClick,
  onShowToast,
  reminders,
  onToggleReminder
}) => {
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [simulatedEmpty, setSimulatedEmpty] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);

  // Selected category names
  const selectedCategories = useMemo(() => {
    return categories.filter((c) => c.selected);
  }, [categories]);

  const selectedCategoryNames = useMemo(() => {
    return selectedCategories.map((c) => c.name.toLowerCase());
  }, [selectedCategories]);

  // Filter events matching active user's chosen categories
  const feedEvents = useMemo(() => {
    if (simulatedEmpty) return [];
    return events.filter((ev) => {
      if (ev.status !== 'active') return false;
      const catLower = ev.category.toLowerCase();
      // Must match at least one selected category
      const matchesUserCategory = selectedCategoryNames.some(
        (sc) => catLower.includes(sc) || sc.includes(catLower)
      );
      if (!matchesUserCategory) return false;

      // Filter tab
      if (activeFilter !== 'all' && catLower !== activeFilter.toLowerCase()) {
        return false;
      }
      return true;
    });
  }, [events, selectedCategoryNames, activeFilter, simulatedEmpty]);

  const categoryTally = useMemo(() => {
    const counts: Record<string, number> = { all: 0 };
    events
      .filter((e) => e.status === 'active')
      .forEach((ev) => {
        const cat = ev.category.toLowerCase();
        counts[cat] = (counts[cat] || 0) + 1;
        if (selectedCategoryNames.some((sc) => cat.includes(sc) || sc.includes(cat))) {
          counts.all++;
        }
      });
    return counts;
  }, [events, selectedCategoryNames]);

  const handleSyncFeed = () => {
    if (isSyncing) return;
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
      onShowToast(
        'Feed synced with Bengaluru civic board',
        'Updated with latest registered venue permits and seat allotments.'
      );
    }, 700);
  };

  const handleSubscribeDigest = () => {
    onShowToast(
      'Digest Subscribed',
      'Weekly Thursday dispatch scheduled for Arun K. (WhatsApp & Email).'
    );
  };

  return (
    <div className="relative w-full pb-12">
      <div className="max-w-7xl mx-auto px-4 md:px-8 pt-6 flex flex-col gap-6">
        {/* Top Dynamic Sync Pill & Status Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#fcf2eb] px-4 py-2.5 rounded-xl shadow-sm border border-[#eae1da]/70">
          <div className="flex items-center gap-3">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#005338] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#005338]"></span>
            </span>
            <span className="text-xs sm:text-sm font-semibold text-[#1f1b17]">
              Feed auto-refreshed 10m ago
            </span>
            <span className="text-[#c7c4d8] text-xs hidden sm:inline">•</span>
            <span className="text-xs text-[#464555] hidden sm:inline">
              4 new events added this week
            </span>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5 text-xs text-[#464555]">
              <span className="material-symbols-outlined text-[16px] text-[#005338]">
                verified_user
              </span>
              <span>Curated for Arun K.</span>
            </div>
            <button
              type="button"
              disabled={isSyncing}
              onClick={handleSyncFeed}
              className="flex items-center gap-1 px-3 py-1 rounded-md bg-white hover:bg-[#f6ece6] transition-colors text-xs font-semibold text-[#1f1b17] shadow-xs cursor-pointer border border-[#eae1da]"
            >
              <span
                className={`material-symbols-outlined text-[14px] ${
                  isSyncing ? 'animate-spin' : ''
                }`}
              >
                sync
              </span>
              <span>Sync</span>
            </button>
          </div>
        </div>

        {/* Page Editorial Header Area */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
          <div className="flex flex-col gap-1 max-w-2xl">
            <div className="flex items-center gap-3 flex-wrap">
              <span className="px-3 py-0.5 rounded-full bg-[#e2dfff] text-[#0f0069] text-xs font-bold tracking-wide uppercase">
                Curated Stream
              </span>
              <span className="px-3 py-0.5 rounded-full bg-[#f0e6e0] text-[#464555] text-xs font-semibold flex items-center gap-1">
                <span className="material-symbols-outlined text-[14px] text-[#3525cd]">
                  interests
                </span>
                <span>{selectedCategories.length} Active Interests</span>
              </span>
            </div>

            <h1 className="text-3xl md:text-4xl font-bold text-[#1f1b17] tracking-tight mt-1">
              My Personalized Feed
            </h1>
            <p className="text-sm md:text-base text-[#464555]">
              Upcoming gatherings matching your curated categories:{' '}
              {selectedCategories.map((c, idx) => (
                <span key={c.id} className="font-semibold text-[#1f1b17]">
                  {c.name}
                  {idx < selectedCategories.length - 1 ? ', ' : '.'}
                </span>
              ))}
            </p>
          </div>

          {/* Preferences CTA and Quick Stats Tile */}
          <div className="flex items-center gap-3 self-start lg:self-end">
            <button
              type="button"
              onClick={() => onNavigate('favourite-categories')}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#f6ece6] hover:bg-[#f0e6e0] text-[#1f1b17] text-xs font-semibold transition-all shadow-xs border border-[#eae1da] cursor-pointer"
            >
              <span className="material-symbols-outlined text-[18px] text-[#3525cd]">
                tune
              </span>
              <span>Edit Preferences</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setSimulatedEmpty(!simulatedEmpty);
                onShowToast(
                  simulatedEmpty ? 'Feed Restored' : 'Simulating Empty Stream',
                  simulatedEmpty
                    ? 'Showing matching personalized events.'
                    : 'Demonstrating empty results zero state.'
                );
              }}
              title="Simulate filter state with no results"
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold transition-all shadow-xs cursor-pointer border border-[#eae1da] ${
                simulatedEmpty
                  ? 'bg-[#e9e1dd] text-[#1f1b17]'
                  : 'bg-[#fcf2eb] hover:bg-[#f6ece6] text-[#464555]'
              }`}
            >
              <span className="material-symbols-outlined text-[18px]">
                filter_alt_off
              </span>
              <span className="hidden sm:inline">
                {simulatedEmpty ? 'Reset Simulation' : 'Simulate Empty'}
              </span>
            </button>
          </div>
        </div>

        {/* Category Filter Segment Navigation */}
        <div className="flex flex-wrap items-center justify-between gap-4 pt-1">
          <div className="flex flex-wrap items-center gap-1.5 p-1 rounded-xl bg-[#f6ece6] border border-[#eae1da]">
            <button
              type="button"
              onClick={() => setActiveFilter('all')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeFilter === 'all'
                  ? 'bg-white text-[#1f1b17] shadow-sm'
                  : 'text-[#464555] hover:text-[#1f1b17]'
              }`}
            >
              <span>All Matches</span>
              <span className="px-1.5 py-0.2 rounded-full bg-[#f0e6e0] text-[#464555] text-[10px]">
                {categoryTally.all || 0}
              </span>
            </button>

            {selectedCategories.map((cat) => {
              const catKey = cat.name.toLowerCase();
              const isCatActive = activeFilter === catKey;
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setActiveFilter(catKey)}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                    isCatActive
                      ? 'bg-white text-[#1f1b17] shadow-sm'
                      : 'text-[#464555] hover:text-[#1f1b17]'
                  }`}
                >
                  <span
                    className={`h-2 w-2 rounded-full ${
                      cat.id === 'music'
                        ? 'bg-[#3525cd]'
                        : cat.id === 'workshop'
                        ? 'bg-[#625d5b]'
                        : 'bg-[#005338]'
                    }`}
                  />
                  <span>{cat.name}</span>
                  <span className="px-1.5 py-0.2 rounded-full bg-[#f0e6e0] text-[#464555] text-[10px]">
                    {categoryTally[catKey] || 0}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-2 text-[#464555] text-xs">
            <span>Sort by:</span>
            <div className="flex items-center gap-1 font-semibold text-[#1f1b17] cursor-pointer">
              <span>Upcoming (Chronological)</span>
              <span className="material-symbols-outlined text-[16px]">
                expand_more
              </span>
            </div>
          </div>
        </div>

        {/* Empty State when zero matches or simulated */}
        {feedEvents.length === 0 ? (
          <div className="flex flex-col items-center justify-center p-8 md:p-12 bg-[#fcf2eb] rounded-2xl text-center max-w-xl mx-auto my-6 border border-[#eae1da] shadow-sm">
            <div className="w-16 h-16 rounded-2xl bg-[#f0e6e0] flex items-center justify-center mb-4 text-[#464555]">
              <span className="material-symbols-outlined text-[32px]">
                event_busy
              </span>
            </div>
            <h3 className="text-xl font-bold text-[#1f1b17]">
              No events found in this category
            </h3>
            <p className="text-sm text-[#464555] mt-1 max-w-md">
              There are currently no scheduled gatherings matching this filter. Try adjusting your category selections or check back tomorrow morning.
            </p>
            <div className="flex items-center gap-3 mt-6">
              <button
                type="button"
                onClick={() => {
                  setSimulatedEmpty(false);
                  setActiveFilter('all');
                }}
                className="px-4 py-2 rounded-lg bg-[#3525cd] text-white hover:bg-[#4f46e5] text-xs font-semibold transition-colors shadow-sm cursor-pointer"
              >
                Show All Matches
              </button>
              <button
                type="button"
                onClick={() => onNavigate('favourite-categories')}
                className="px-4 py-2 rounded-lg bg-white hover:bg-[#f6ece6] text-[#1f1b17] text-xs font-semibold transition-colors shadow-xs border border-[#eae1da] cursor-pointer"
              >
                Add More Categories
              </button>
            </div>
          </div>
        ) : (
          /* Main Feed Grid */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-1">
            {feedEvents.map((event) => {
              const isReminder = reminders[event.id] || false;

              let catBadge = 'bg-[#e2dfff] text-[#0f0069]';
              let iconName = 'music_note';
              if (event.category === 'Workshop') {
                catBadge = 'bg-[#e9e1dd] text-[#1e1b19]';
                iconName = 'handyman';
              } else if (event.category === 'Sports') {
                catBadge = 'bg-[#85f8c4] text-[#002114]';
                iconName = 'directions_run';
              } else if (event.category === 'Food') {
                catBadge = 'bg-[#f0e6e0] text-[#464555]';
                iconName = 'restaurant';
              }

              return (
                <article
                  key={event.id}
                  className="group flex flex-col bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 border border-[#eae1da]/70"
                >
                  <div className="relative w-full aspect-video overflow-hidden bg-[#f6ece6]">
                    <img
                      src={event.imageUrl}
                      alt={event.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent"></div>

                    {/* Category Badge */}
                    <div className="absolute top-3 left-3 flex items-center gap-1.5">
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-xs font-semibold shadow-xs flex items-center gap-1 ${catBadge}`}
                      >
                        <span className="material-symbols-outlined text-[13px]">
                          {iconName}
                        </span>
                        <span>{event.category}</span>
                      </span>
                    </div>

                    {/* Matched Reason Tag */}
                    <div className="absolute bottom-2.5 left-3 flex items-center gap-1 px-2 py-0.5 rounded bg-white/90 backdrop-blur-sm text-[#1f1b17] text-[11px] font-semibold">
                      <span className="material-symbols-outlined text-[13px] text-[#3525cd]">
                        auto_awesome
                      </span>
                      <span>Matched via {event.category}</span>
                    </div>

                    {/* Reminder Bell */}
                    <button
                      type="button"
                      onClick={() => onToggleReminder(event.id, event.title)}
                      title={isReminder ? 'Reminder Active' : 'Set Reminder'}
                      className={`absolute top-3 right-3 w-8 h-8 rounded-full flex items-center justify-center shadow-md transition-transform active:scale-90 cursor-pointer ${
                        isReminder
                          ? 'bg-[#3525cd] text-white'
                          : 'bg-white/80 hover:bg-white text-[#464555] hover:text-[#1f1b17]'
                      }`}
                    >
                      <span
                        className="material-symbols-outlined text-[18px]"
                        style={{
                          fontVariationSettings: isReminder ? "'FILL' 1" : "'FILL' 0"
                        }}
                      >
                        {isReminder ? 'notifications_active' : 'notifications'}
                      </span>
                    </button>
                  </div>

                  <div className="p-4 flex flex-col flex-1 justify-between gap-4">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center justify-between text-xs text-[#464555]">
                        <span className="flex items-center gap-1 text-[#3525cd] font-semibold">
                          <span className="material-symbols-outlined text-[16px]">
                            calendar_today
                          </span>
                          <span>{event.dateTime}</span>
                        </span>
                        <span className="flex items-center gap-0.5 text-[#625d5b]">
                          <span className="material-symbols-outlined text-[15px]">
                            location_on
                          </span>
                          <span>{event.neighborhood.split(',')[0]}</span>
                        </span>
                      </div>

                      <h2
                        onClick={() => onDesignPass(event.id)}
                        className="text-base font-bold text-[#1f1b17] tracking-tight group-hover:text-[#3525cd] transition-colors line-clamp-2 mt-0.5 cursor-pointer"
                      >
                        {event.title}
                      </h2>
                      <p className="text-xs text-[#464555] line-clamp-2 leading-relaxed">
                        {event.description}
                      </p>
                    </div>

                    <div className="flex flex-col gap-2 pt-1 border-t border-[#eae1da]/50">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {event.spotsLeft !== undefined ? (
                            <div className="flex items-center gap-1 text-xs text-[#ba1a1a] font-semibold">
                              <span className="w-1.5 h-1.5 rounded-full bg-[#ba1a1a] animate-pulse"></span>
                              <span>Only {event.spotsLeft} spots left</span>
                            </div>
                          ) : (
                            <div className="flex items-center gap-2">
                              <div className="flex -space-x-1.5">
                                <div className="w-6 h-6 rounded-full bg-[#e9e1dd] flex items-center justify-center text-[10px] font-semibold text-[#1e1b19]">
                                  AK
                                </div>
                                <div className="w-6 h-6 rounded-full bg-[#e2dfff] flex items-center justify-center text-[10px] font-semibold text-[#0f0069]">
                                  PS
                                </div>
                              </div>
                              <span className="text-[11px] text-[#464555]">
                                {event.attendeesCount} attending
                              </span>
                            </div>
                          )}
                        </div>

                        <div className="text-base font-bold text-[#1f1b17]">
                          {event.isFree ? 'Free' : `₹${event.price.toLocaleString()}`}
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => onDesignPass(event.id)}
                          className="flex-1 py-2 px-3 rounded-lg bg-[#f6ece6] hover:bg-[#f0e6e0] text-[#1f1b17] text-xs font-semibold transition-colors text-center cursor-pointer"
                        >
                          View Pass
                        </button>
                        <button
                          type="button"
                          onClick={() => onRsvpClick(event)}
                          className="flex-1 py-2 px-3 rounded-lg bg-[#3525cd] hover:bg-[#4f46e5] text-white text-xs font-semibold shadow-xs transition-colors text-center cursor-pointer"
                        >
                          {event.isFree ? 'Join Group' : 'RSVP Spot'}
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            onShowToast('Share Link Copied', `Link to ${event.title} copied.`)
                          }
                          title="Share event"
                          className="p-2 rounded-lg bg-[#f6ece6] hover:bg-[#f0e6e0] text-[#464555] hover:text-[#1f1b17] transition-colors cursor-pointer"
                        >
                          <span className="material-symbols-outlined text-[18px]">
                            share
                          </span>
                        </button>
                      </div>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}

        {/* Weekly Digest & Notification Callout Card */}
        <div className="relative overflow-hidden rounded-2xl bg-[#fcf2eb] p-6 flex flex-col md:flex-row items-center justify-between gap-6 shadow-sm border border-[#eae1da] mt-4">
          <div className="flex items-start gap-4 max-w-xl">
            <div className="p-3 rounded-xl bg-[#3525cd] text-white hidden sm:flex items-center justify-center shadow-xs">
              <span className="material-symbols-outlined text-[24px]">
                mark_email_unread
              </span>
            </div>
            <div className="flex flex-col gap-0.5">
              <span className="text-xs font-bold text-[#3525cd] uppercase tracking-wide">
                Civic Dispatch Service
              </span>
              <h4 className="text-base md:text-lg font-bold text-[#1f1b17]">
                Get your weekly personalized digest via WhatsApp or Email
              </h4>
              <p className="text-xs text-[#464555] leading-relaxed">
                Every Thursday at 6:00 PM, we deliver early-bird registrations for your active categories directly to your inbox.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 w-full md:w-auto">
            <button
              type="button"
              onClick={() =>
                onShowToast('Digest Frequency', 'Frequency set to: Weekly Thursday.')
              }
              className="w-full md:w-auto px-4 py-2.5 rounded-lg bg-[#eae1da] hover:bg-[#e9e1dd] text-[#1f1b17] text-xs font-semibold transition-colors shadow-xs cursor-pointer"
            >
              Manage Frequency
            </button>
            <button
              type="button"
              onClick={handleSubscribeDigest}
              className="w-full md:w-auto px-5 py-2.5 rounded-lg bg-[#3525cd] hover:bg-[#4f46e5] text-white text-xs font-semibold transition-colors shadow-xs cursor-pointer whitespace-nowrap"
            >
              Subscribe Digest
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
