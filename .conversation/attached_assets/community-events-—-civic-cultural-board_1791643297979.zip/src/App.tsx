/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  AppScreen,
  EventItem,
  CategoryPreference,
  CardDesignState,
  ToastMessage
} from './types';
import { INITIAL_EVENTS, INITIAL_CATEGORIES, STICKER_CATALOG } from './data/mockEvents';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { Toast } from './components/Toast';
import { RsvpModal } from './components/RsvpModal';
import { DiscoverEvents } from './components/DiscoverEvents';
import { FavouriteCategories } from './components/FavouriteCategories';
import { CardDesigner } from './components/CardDesigner';
import { AdminPortal } from './components/AdminPortal';
import { MyFeed } from './components/MyFeed';
import { AuthView } from './components/AuthView';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<AppScreen>('discover-events');
  const [selectedCity, setSelectedCity] = useState<string>('Bengaluru');
  const [events, setEvents] = useState<EventItem[]>(INITIAL_EVENTS);
  const [categories, setCategories] = useState<CategoryPreference[]>(INITIAL_CATEGORIES);
  const [userEmail, setUserEmail] = useState<string>('arun@civic.community');

  // Reminders map (Card 1 in MyFeed has initial active reminder matching mockup)
  const [reminders, setReminders] = useState<Record<string, boolean>>({
    'evt-7': true
  });

  // Card Design state
  const [designState, setDesignState] = useState<CardDesignState>({
    theme: 'warm-atelier',
    stickers: [STICKER_CATALOG.vinyl, STICKER_CATALOG.coldbrew],
    attendeeName: 'Arun K. Ramaswamy',
    eventId: 'evt-1'
  });

  // Active RSVP Modal event
  const [rsvpEvent, setRsvpEvent] = useState<EventItem | null>(null);

  // Global Toast state
  const [toast, setToast] = useState<ToastMessage | null>(null);
  const [toastTimer, setToastTimer] = useState<NodeJS.Timeout | null>(null);

  const showToast = (title: string, desc: string) => {
    if (toastTimer) clearTimeout(toastTimer);
    setToast({
      id: Date.now().toString(),
      title,
      desc
    });
    const timer = setTimeout(() => {
      setToast(null);
    }, 4000);
    setToastTimer(timer);
  };

  const closeToast = () => {
    if (toastTimer) clearTimeout(toastTimer);
    setToast(null);
  };

  // Reminder toggle
  const handleToggleReminder = (eventId: string, title: string) => {
    setReminders((prev) => {
      const nextState = !prev[eventId];
      if (nextState) {
        showToast(
          `✓ Reminder set for ${title}`,
          "We'll email you 24 hours prior with gate instructions."
        );
      } else {
        showToast(
          'Reminder cancelled',
          `You won't receive notifications for ${title}.`
        );
      }
      return { ...prev, [eventId]: nextState };
    });
  };

  // Toggle Category
  const handleToggleCategory = (id: string) => {
    setCategories((prev) =>
      prev.map((c) => (c.id === id ? { ...c, selected: !c.selected } : c))
    );
  };

  // Toggle Event Status from Admin
  const handleToggleEventStatus = (id: string) => {
    setEvents((prev) =>
      prev.map((e) => {
        if (e.id === id) {
          const nextStatus = e.status === 'active' ? 'inactive' : 'active';
          showToast(
            nextStatus === 'active' ? 'Event Published' : 'Event Unpublished',
            nextStatus === 'active'
              ? `"${e.title}" is now discoverable in Bengaluru.`
              : `"${e.title}" hidden from public discovery feeds.`
          );
          return { ...e, status: nextStatus };
        }
        return e;
      })
    );
  };

  // Save/Update Event from Admin
  const handleSaveEvent = (eventData: Partial<EventItem> & { id?: string }) => {
    if (eventData.id) {
      // Update existing
      setEvents((prev) =>
        prev.map((e) =>
          e.id === eventData.id ? ({ ...e, ...eventData } as EventItem) : e
        )
      );
    } else {
      // Create new
      const newEvent: EventItem = {
        id: `evt-${Date.now()}`,
        title: eventData.title || 'Untitled Community Event',
        category: eventData.category || 'Music',
        city: eventData.city || 'Bengaluru',
        venue: eventData.venue || 'Indiranagar Pavilion',
        neighborhood: eventData.neighborhood || 'Indiranagar, Bengaluru',
        dateTime: eventData.dateTime || 'Sat, Apr 19 • 6:00 PM IST',
        price: eventData.price ?? 500,
        isFree: eventData.isFree ?? false,
        imageUrl:
          eventData.imageUrl ||
          'https://lh3.googleusercontent.com/aida-public/AB6AXuCvcVUPidmDGadPKLPQqOis_1MSA4KQ35npFzyyjdUj2h2TLQaDGNQBiFWhLi08kFCUoSmbJ-kyLIvi9hV23E5kJPZfr4RQiAHPjJvH4sc_z0v8FK5FidltdzwGUG_kxIInUy3GqA9BbURvb0tC1WMtjkw_WcOYxjbzeWJ1r5e0SiBDR6yyicjirGSVVjxarF1QTVncp6kDe7QXvb8KF33aEXuE3FDbBCqlCD3zJbU_ZkvAFE0ZXMwQ',
        imageAlt: eventData.title || 'Event photo',
        description:
          eventData.description || 'Community gathering and cultural showcase.',
        status: eventData.status || 'active',
        attendeesCount: 0
      };
      setEvents((prev) => [newEvent, ...prev]);
    }
  };

  // Archive Event
  const handleArchiveEvent = (id: string) => {
    setEvents((prev) => prev.filter((e) => e.id !== id));
    showToast('Event Archived', 'Event moved to historical records.');
  };

  // Navigate to Card Designer for a specific event
  const handleDesignPassForEvent = (eventId: string, attendeeName?: string) => {
    setDesignState((prev) => ({
      ...prev,
      eventId,
      ...(attendeeName ? { attendeeName } : {})
    }));
    setCurrentScreen('card-designer');
  };

  return (
    <div className="min-h-screen bg-[#fff8f5] text-[#1f1b17] flex flex-col font-sans selection:bg-[#3525cd]/15 selection:text-[#3525cd]">
      {/* Universal Fixed Header */}
      <Header
        currentScreen={currentScreen}
        onNavigate={setCurrentScreen}
        selectedCity={selectedCity}
        onSelectCity={setSelectedCity}
        userEmail={userEmail}
      />

      {/* Main Content Router */}
      <main className="w-full pt-16 bg-[#fff8f5] flex-1">
        {currentScreen === 'discover-events' && (
          <DiscoverEvents
            events={events}
            selectedCity={selectedCity}
            onSelectCity={setSelectedCity}
            onSelectEventForDesign={(ev) => handleDesignPassForEvent(ev.id)}
            onRsvpClick={(ev) => setRsvpEvent(ev)}
            onShowToast={showToast}
            reminders={reminders}
            onToggleReminder={handleToggleReminder}
          />
        )}

        {currentScreen === 'favourite-categories' && (
          <FavouriteCategories
            categories={categories}
            onToggleCategory={handleToggleCategory}
            onSavePreferences={() => {
              // Saved
            }}
            onNavigate={setCurrentScreen}
            onShowToast={showToast}
          />
        )}

        {currentScreen === 'card-designer' && (
          <CardDesigner
            events={events}
            currentEventId={designState.eventId}
            onSelectEvent={(id) => setDesignState((prev) => ({ ...prev, eventId: id }))}
            designState={designState}
            onUpdateDesign={(patch) => setDesignState((prev) => ({ ...prev, ...patch }))}
            onNavigate={setCurrentScreen}
            onShowToast={showToast}
          />
        )}

        {currentScreen === 'admin-portal' && (
          <AdminPortal
            events={events}
            onToggleStatus={handleToggleEventStatus}
            onSaveEvent={handleSaveEvent}
            onArchiveEvent={handleArchiveEvent}
            onNavigate={setCurrentScreen}
            onShowToast={showToast}
            onDesignPass={(eventId) => handleDesignPassForEvent(eventId)}
          />
        )}

        {currentScreen === 'my-feed' && (
          <MyFeed
            events={events}
            categories={categories}
            onNavigate={setCurrentScreen}
            onDesignPass={(eventId) => handleDesignPassForEvent(eventId)}
            onRsvpClick={(ev) => setRsvpEvent(ev)}
            onShowToast={showToast}
            reminders={reminders}
            onToggleReminder={handleToggleReminder}
          />
        )}

        {currentScreen === 'sign-in' && (
          <AuthView
            onNavigate={setCurrentScreen}
            onLoginSuccess={(email) => setUserEmail(email)}
            onShowToast={showToast}
          />
        )}
      </main>

      {/* Universal Footer */}
      <Footer />

      {/* RSVP Modal Dialog */}
      <RsvpModal
        event={rsvpEvent}
        onClose={() => setRsvpEvent(null)}
        onConfirm={(name, count) => {
          if (rsvpEvent) {
            setEvents((prev) =>
              prev.map((ev) =>
                ev.id === rsvpEvent.id
                  ? { ...ev, attendeesCount: ev.attendeesCount + count }
                  : ev
              )
            );
            showToast(
              'RSVP Recorded',
              `${count} admission pass confirmed for ${name}.`
            );
          }
        }}
        onCustomizePass={(eventId, name) => {
          handleDesignPassForEvent(eventId, name);
        }}
      />

      {/* Toast Notification */}
      <Toast toast={toast} onClose={closeToast} />
    </div>
  );
}
